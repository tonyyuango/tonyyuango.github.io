package method;

import util.Record;

import java.io.*;
import java.util.*;

public class CaseStudy {
	public static ArrayList<Record> readTwitterRecords(String filePath) throws Exception{
		BufferedReader in = new BufferedReader(new InputStreamReader(
				new FileInputStream(filePath), "UTF-8"));
		String s;
		ArrayList<Record> records = new ArrayList<Record>();
		int t = 0;
		while ((s = in.readLine()) != null) {
			Integer val = Integer.valueOf(s);
			records.add(new Record(t, val));
			t++;
		}
		in.close();
		return records;
	}
	private static ArrayList<Record> readMITRecords(String dirPath, Integer user, Integer v) throws Exception{
		BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath+user+".txt"), "UTF-8"));
		String s;
		ArrayList<Record> records = new ArrayList<Record>();
		int t = 0;
		while ((s = in.readLine()) != null) {
			String[] sl = s.split(",");
			Integer val;
			for(int i = 0; i < sl.length; i++){
				if(sl[i].equals("NaN")){
					val = 0;
				}else{
					Integer sig = Integer.valueOf(sl[i]);
					if(sig == 0)
						val = 0;
					else if(sig == v)
						val = 1;
					else
						val = -1;
				}
				records.add(new Record(t, val));
				t++;
			}
		}
		in.close();
		return records;
	}
	public static ArrayList<Record> getTrainRecords(ArrayList<Record> records, double ratio){
		ArrayList<Record> records_train =  new ArrayList<Record>();
		int cnt = 0;
		for(Record record : records){
			if(record.getV() != 0)
				cnt++;
		}
		int cnt_train = 0;
		for(Record record : records){
			records_train.add(record);
			if(record.getV() != 0){
				cnt_train++;
				if(cnt_train > cnt * ratio)
					break;
			}
		}
		return records_train;
	}
	public static ArrayList<Record> getTestRecords(ArrayList<Record> records, double ratio){
		ArrayList<Record> records_test =  new ArrayList<Record>();
		int cnt = 0;
		for(Record record : records){
			if(record.getV() != 0)
				cnt++;
		}
		int cnt_train = 0;
		for(Record record : records){
			if(record.getV() != 0){
				cnt_train++;
				if(cnt_train > cnt * ratio){
					records_test.add(record);
				}
			}
		}
		return records_test;
	}
	public static void MITDataPredictionPreRecF1Acc(double ratio, String dirPath) throws Exception{
		int u_cnt = 0;
		double[] pre_rec_f1_acc_macro = new double[4];
		double[] result_micro = new double[4];

		for(int user = 1; user < 107; user++){
			System.out.println("user: "+user);
			int L_max = 200;
//			ArrayList<Record> records =  readMITRecords("E:/Dropbox/data/mobility/RealityMining/", user, 2);
			ArrayList<Record> records =  readMITRecords(dirPath, user, 2);
			ArrayList<Record> records_train = getTrainRecords(records, ratio);
			ArrayList<Record> records_test = getTestRecords(records, ratio);
			CoverageEfficient ce = new CoverageEfficient(records_train, L_max, ratio);
			ce.findL();
			double[] ce_results = ce.testFutureEvent(records_test);
			Double ce_pre = ce_results[0]/(ce_results[0]+ce_results[2]);
			Double ce_rec = ce_results[0]/(ce_results[0]+ce_results[3]);
			if(ce_pre.isNaN()){
				ce_pre = 0.0;
			}
			if(ce_rec.isNaN()){
				ce_rec = 0.0;
			}
			Double ce_f1 = 2 * ce_pre * ce_rec / (ce_pre + ce_rec);
			if(ce_f1.isNaN()){
				ce_f1 = 0.0;
			}
			Double ce_acc = (ce_results[0] + ce_results[1]) / (ce_results[0] + ce_results[1] + ce_results[2] + ce_results[3]);
			if(ce_acc.isNaN()){
				ce_acc = 0.0;
			}
			pre_rec_f1_acc_macro[3] += ce_acc;
			pre_rec_f1_acc_macro[0] += ce_pre;
			pre_rec_f1_acc_macro[1] += ce_rec;
			pre_rec_f1_acc_macro[2] += ce_f1;
			result_micro[0] += ce_results[0];
			result_micro[1] += ce_results[1];
			result_micro[2] += ce_results[2];
			result_micro[3] += ce_results[3];
			u_cnt++;
		}
		for(int i = 0; i < 4; i++){
			pre_rec_f1_acc_macro[i] /= u_cnt;
		}
		System.out.println("macro: ");
		System.out.println(Arrays.toString(pre_rec_f1_acc_macro).replace("[","").replace("]", "").replace(", ", "\t"));
		System.out.println("micro: ");
		double micro_pre = result_micro[0]/(result_micro[0]+result_micro[2]);
		double micro_rec = result_micro[0]/(result_micro[0]+result_micro[3]);
		double micro_f1 = 2 * micro_pre * micro_rec / (micro_pre + micro_rec);
		double micro_acc = (result_micro[0] + result_micro[1]) / (result_micro[0] + result_micro[1] + result_micro[2] + result_micro[3]);
		System.out.println(micro_pre + "\t" + micro_rec + "\t" + micro_f1 + "\t" + micro_acc);
	}
	public static void TwitterDataPredictionPreRecF1Acc(double ratio, String dirPath) throws Exception{
		int u_cnt = 0;
		double[] pre_rec_f1_acc_macro = new double[4];
		double[] result_micro = new double[4];

//		File[] f_list = new File("/Users/quanyuan/Dropbox/data/mobility/crawler/twitter/").listFiles();
		File[] f_list = new File(dirPath).listFiles();
		for(File f : f_list){
			if(f.isDirectory())
				continue;
			System.out.println(f.getName());
			ArrayList<Record> records =  readTwitterRecords(f.getAbsolutePath());
			int L_max = 200;
			ArrayList<Record> records_train = getTrainRecords(records, ratio);
			ArrayList<Record> records_test = getTestRecords(records, ratio);
			if(records_train.size() == 0)
				continue;
			CoverageEfficient ce = new CoverageEfficient(records_train, L_max, ratio);
			ce.findL();
			double[] ce_results = ce.testFutureEvent(records_test);
			Double ce_pre = ce_results[0]/(ce_results[0]+ce_results[2]);
			Double ce_rec = ce_results[0]/(ce_results[0]+ce_results[3]);
			if(ce_pre.isNaN()){
				ce_pre = 0.0;
			}
			if(ce_rec.isNaN()){
				ce_rec = 0.0;
			}
			Double ce_f1 = 2 * ce_pre * ce_rec / (ce_pre + ce_rec);
			if(ce_f1.isNaN()){
				ce_f1 = 0.0;
			}
			Double ce_acc = (ce_results[0] + ce_results[1]) / (ce_results[0] + ce_results[1] + ce_results[2] + ce_results[3]);
			if(ce_acc.isNaN()){
				ce_acc = 0.0;
			}
			pre_rec_f1_acc_macro[3] += ce_acc;
			pre_rec_f1_acc_macro[0] += ce_pre;
			pre_rec_f1_acc_macro[1] += ce_rec;
			pre_rec_f1_acc_macro[2] += ce_f1;
			result_micro[0] += ce_results[0];
			result_micro[1] += ce_results[1];
			result_micro[2] += ce_results[2];
			result_micro[3] += ce_results[3];
			u_cnt++;
		}
		for(int i = 0; i < 4; i++){
			pre_rec_f1_acc_macro[i] /= u_cnt;
		}
		System.out.println("macro: ");
		System.out.println(Arrays.toString(pre_rec_f1_acc_macro).replace("[","").replace("]", "").replace(", ", "\t"));
		System.out.println("micro: ");
		double micro_pre = result_micro[0]/(result_micro[0]+result_micro[2]);
		double micro_rec = result_micro[0]/(result_micro[0]+result_micro[3]);
		double micro_f1 = 2 * micro_pre * micro_rec / (micro_pre + micro_rec);
		double micro_acc = (result_micro[0] + result_micro[1]) / (result_micro[0] + result_micro[1] + result_micro[2] + result_micro[3]);
		System.out.println(micro_pre + "\t" + micro_rec + "\t" + micro_f1 + "\t" + micro_acc);
	}

	public static void MITDataPeriod() throws Exception{
		for(int user = 1; user < 107; user++){
			System.out.println("user: "+user);
			double alpha = 0.8;
			int L_max = 200;
			ArrayList<Record> records =  readMITRecords("/Users/quanyuan/Dropbox/data/mobility/RealityMining/", user, 2);
			double cnt = 0;
			for(Record r:records)
				if(r.getV() != 0)
					cnt++;
			System.out.println(records.size()+"\t"+cnt/records.size());
			if(records.size() == 0)
				continue;

			CoverageEfficient ce = new CoverageEfficient(records, L_max, alpha);
			HashMap<Integer, HashSet<Integer>> ce_results = ce.findL();
			System.out.println(ce_results.keySet());
		}
	}
	public static void TwitterData() throws Exception{
		File[] f_list = new File("/Users/quanyuan/Dropbox/data/mobility/crawler/twitter/").listFiles();
		for(File f : f_list){
			if(f.isDirectory())
				continue;
			System.out.println(f.getName());
			ArrayList<Record> records =  readTwitterRecords(f.getAbsolutePath());
			double cnt = 0;
			for(Record r:records)
				if(r.getV() != 0)
					cnt++;
			System.out.println(records.size()+"\t"+cnt/records.size());
			double alpha = 0.7;
			int L_max = 200;
			
			CoverageEfficient ce = new CoverageEfficient(records, L_max, alpha);
			System.out.println("TiCom");
			ce.findL();
		}
	}
}
