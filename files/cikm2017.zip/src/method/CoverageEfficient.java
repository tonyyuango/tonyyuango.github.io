package method;

import util.Record;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;

public class CoverageEfficient extends CoverageBase {
	int[] P;
	int[][] S_tp, S_fp;
	boolean[][] S_valid;
	double[][] S_val;
	public CoverageEfficient(ArrayList<Record> records, int L_max, double alpha) throws Exception {
		super(records, L_max, alpha);
	}

	private void initialSScore() throws Exception {
		S_tp = new int[L_max][L_max];
		S_fp = new int[L_max][L_max];
		S_valid = new boolean[L_max][L_max];
		S_val = new double[L_max][L_max];
		for (int L = 2; L < L_max; L++) {
			Arrays.fill(S_valid[L], true);
			for (int i = 0; i < N; i++) {
				if (O[i] == 1)
					S_tp[L][i % L]++;
				else if (O[i] == -1)
					S_fp[L][i % L]++;
			}
			for (int l = 0; l < L; l++) {
				double score = (1 - alpha) * S_tp[L][l] / T_cnt - alpha * S_fp[L][l] / F_cnt + alpha;
				if(score > alpha)
					S_val[L][l] = score;
			}
		}
	}

	private String top1S() {
		double score_max = 0;
		String S = null;
		for(int L = 2; L < L_max; L++){
			for (int l = 0; l < L; l++) {
				if(S_valid[L][l] == false)
					continue;
				if(S_val[L][l] > score_max){
					score_max = S_val[L][l];
					S = L + "\t" + l; 
				}
			}
		}
		return S;
	}
	private void updateS_tpfp_val(int L, int l){
		HashSet<String> S_changed = new HashSet<String>();
		for(int i = l; i < N; i += L){
			if(P[i] == 0 && O[i] != 0){
				for (Integer L_tmp = 2; L_tmp < L_max; L_tmp++) {
					int l_tmp = i % L_tmp;
					if(S_valid[L_tmp][l_tmp] == false)
						continue;
					if (O[i] > 0)
						S_tp[L_tmp][l_tmp]--;
					else if (O[i] < 0)
						S_fp[L_tmp][l_tmp]--;
					S_changed.add(L_tmp+"\t"+l_tmp);
				}
				P[i] = 1;
			}
		}
		for (String S : S_changed) {
			Integer L_tmp = Integer.valueOf(S.split("\t")[0]);
			Integer l_tmp = Integer.valueOf(S.split("\t")[1]);
			double score = (1 - alpha) * S_tp[L_tmp][l_tmp] / T_cnt - alpha * S_fp[L_tmp][l_tmp] / F_cnt + alpha;
			if(score > alpha)
				S_val[L_tmp][l_tmp] = score;
			else
				S_val[L_tmp][l_tmp] = 0;
		}

		for(int L_tmp = L; L_tmp < L_max; L_tmp += L){
			for(int l_tmp = l; l_tmp < L_tmp; l_tmp += L){
				S_valid[L_tmp][l_tmp] = false;
			}
		}
	}
	String S;
	HashMap<Integer, HashSet<Integer>> L_l_set = new HashMap<Integer, HashSet<Integer>>();
	public HashMap<Integer, HashSet<Integer>> findL() throws Exception {
		double[] L_threshold = getThresholdScore(O, 50, 100);
		P = new int[N];
		initialSScore();
		S = top1S();
		while(S != null){
			Integer L = Integer.valueOf(S.split("\t")[0]);
			Integer l = Integer.valueOf(S.split("\t")[1]);
			double val = S_val[L][l];
			if(val < L_threshold[L]){
				S_valid[L][l] = false;
				S = top1S();
				continue;
			}
//			System.out.println(L+"\t"+l+"\t"+S_val[L][l]+"\t"+L_threshold[L]);
			if(!L_l_set.containsKey(L)){
				L_l_set.put(L, new HashSet<Integer>());
				System.out.println(L*1.0/24);
//				if(L_l_set.size() > 2)
//					break;
			}
			L_l_set.get(L).add(l);
			updateS_tpfp_val(L, l);
			S = top1S();
		}
//		System.out.println(L_l_set.toString());
		return L_l_set;
	}
	public double[] testFutureEvent(ArrayList<Record> records_test){
		double[] results = new double[4];	//tp fn fp tn
		if(L_l_set.size() == 0)
			return new double[]{0, 0, 0, 0};
		for(Record record : records_test){
			int t = record.getT();
			int v_true = record.getV();
			if(v_true != 0){
				int v_predict = -1;
				for(Entry<Integer, HashSet<Integer>> entry : L_l_set.entrySet()){
					int L = entry.getKey();
					if(entry.getValue().contains(t % L))
						v_predict = 1;
				}
				if(v_true == 1 && v_predict == 1){		//tp
					results[0]++;
				}else if(v_true == -1 && v_predict == -1){	//fn
					results[1]++;
				}else if(v_true == -1 && v_predict == 1){		//fp
					results[2]++;
				}else if(v_true == 1 && v_predict == -1){		//tn
					results[3]++;
				}
//				System.out.println(v_true+"\t"+v_predict);
			}
		}
		return results;
	}
	public double testFutureEventAcc(ArrayList<Record> records_test){
		double acc = 0;
		int cnt = 0;
		if(L_l_set.size() == 0)
			return 0;
		for(Record record : records_test){
			int t = record.getT();
			int v_true = record.getV();
			if(v_true != 0){
				cnt++;
				int v_predict = -1;
				for(Entry<Integer, HashSet<Integer>> entry : L_l_set.entrySet()){
					int L = entry.getKey();
					if(entry.getValue().contains(t % L))
						v_predict = 1;
				}
				if(v_true == v_predict){
					acc++;
				}
			}
		}
		return acc / cnt;
	}

}
