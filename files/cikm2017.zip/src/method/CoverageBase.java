package method;

import util.Record;
import util.Utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


public class CoverageBase {
	protected Random rand = new Random(100);
	protected int[] O; // observation sequence, transformed from raw records
	protected int T_cnt = 0, F_cnt = 0, N; // #positive observations, #negative observations, length of
	protected int L_max;
	protected double alpha;
	public CoverageBase(ArrayList<Record> records, int L_max, double alpha) throws Exception {
		this.L_max = L_max;
		this.N = records.size();
		this.alpha = alpha;
		O = new int[N];
		for (Record r : records) {
			int t = r.getT();
			if (r.getV() == 1) {
				O[t] = 1;
				T_cnt++;
			}else if (r.getV() == -1) {
				O[t] = -1;
				F_cnt++;
			}
		}
	}

	protected HashMap<String, Double> getPositiveSlotScore(int[] H, int L) throws Exception {
		HashMap<String, Double> slot_score = new HashMap<String, Double>();
		int[] l_tp = new int[L];
		int[] l_fp = new int[L];
		for (int i = 0; i < N; i++) {
			if (H[i] == 1)
				l_tp[i % L]++;
			else if (H[i] == -1)
				l_fp[i % L]++;
		}
		for (int l = 0; l < L; l++) {
			double score = (1-alpha) * l_tp[l] / T_cnt - alpha * l_fp[l] / F_cnt + alpha;
			if (score > alpha) {
				String slot = L + "\t" + l;
				slot_score.put(slot, score);
			}
		}
		return slot_score;
	}
	protected int[] generateRandomPermutation(int[] O) {
		int[] H = new int[O.length];
		for (int i = 0; i < O.length; i++) {
			int j = Math.abs(rand.nextInt() % O.length);
			while (H[j] != 0)
				j = Math.abs(rand.nextInt() % O.length);
			H[j] = O[i];
		}
		return H;
	}

	protected double[] getThresholdScore(int[] O, int r, int k) throws Exception{
		double[][] L_k_val = new double[L_max][k];
		for(int t = 0; t < k; t++){
			int[] H = generateRandomPermutation(O);
			for (int L = 2; L < L_max; L++) {
				HashMap<String, Double> slot_score = getPositiveSlotScore(H, L);
				String l_best = Utility.getTop(slot_score);
				double val = 0;
				if(l_best != null)
					val = slot_score.get(l_best);
				L_k_val[L][t] = val;
			}
		}
		double[] L_threshold = new double[L_max];
		for (int L = 2; L < L_max; L++) {
			ArrayList<Integer> rank = Utility.rankDescend(L_k_val[L]);
			L_threshold[L] = L_k_val[L][rank.get(r)];
		}
		return L_threshold;
	}
}
