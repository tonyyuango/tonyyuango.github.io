package method;

import util.DataGenerator;
import util.Evaluation;
import util.Record;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

/**
 * Created by quanyuan on 2/21/17.
 */
public class Main {
	public static void evaluateSyntheicData() throws Exception {
		//synthetic data
		double alpha = 0.6;
		double beta = 0.1;
		double eta = 0.1;
		int n = 300;
		int seed = 0;
		int L_max = 100;
		String[] ts_str_al = new String[] {"24:10,11,14,15", "32:17", "48:40,41"};	//period: 24; positive slots: 10, 11, 14, 15
		DataGenerator dg = new DataGenerator(beta, eta, n, seed);

		ArrayList<Record> records = dg.generateSequence(ts_str_al);

		CoverageEfficient ce = new CoverageEfficient(records, L_max, alpha);
		HashMap<Integer, HashSet<Integer>> L_l_set_ce = ce.findL();
		double f1_period_detection = Evaluation.evaluateL(ts_str_al, L_l_set_ce);
		double f1_slot_detection = Evaluation.evaluateS(ts_str_al, L_l_set_ce);
		double f1_outlier_detection = Evaluation.evaluateO(records, L_l_set_ce);
		System.out.println(f1_period_detection+"\t"+f1_slot_detection+"\t"+f1_outlier_detection);
	}
	public static void evaluateRealWorldData(String dirPath) throws Exception {
        double ratio = 0.7;
		CaseStudy.MITDataPredictionPreRecF1Acc(ratio, dirPath);
		CaseStudy.TwitterDataPredictionPreRecF1Acc(ratio, dirPath);
	}
    public static void main(String[] args) throws Exception {
//        String dirPath = "";
		evaluateSyntheicData();
    }
}
