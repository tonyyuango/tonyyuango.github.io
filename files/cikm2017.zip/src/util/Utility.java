package util;

import java.util.*;
import java.util.Map.Entry;

public class Utility {
	public static ArrayList<Integer> rankDescend(Map<Integer, Double> map) {
		List<Entry<Integer, Double>> list = new ArrayList<Entry<Integer, Double>>(
				map.entrySet());
		Collections.sort(list,
				new Comparator<Entry<Integer, Double>>() {
					public int compare(
							Entry<Integer, Double> o1,
							Entry<Integer, Double> o2) {
						return o2.getValue().compareTo(
								o1.getValue());
					}
				});
		ArrayList<Integer> results = new ArrayList<Integer>();
		for (int i = 0; i < list.size(); i++) {
			results.add(list.get(i).getKey());
		}
		return results;
	}
	public static ArrayList<String> rankDescendS(HashMap<String, Double> map) {
		List<Entry<String, Double>> list = new ArrayList<Entry<String, Double>>(
				map.entrySet());

		Collections.sort(list,
				new Comparator<Entry<String, Double>>() {
					public int compare(
							Entry<String, Double> o1,
							Entry<String, Double> o2) {
						return o2.getValue().compareTo(
								o1.getValue());
					}
				});
		ArrayList<String> results = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			results.add(list.get(i).getKey());
		}
		return results;
	}
	public static ArrayList<String> rankDescendSI(HashMap<String, Integer> map) {
		List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(
				map.entrySet());

		Collections.sort(list,
				new Comparator<Entry<String, Integer>>() {
					public int compare(
							Entry<String, Integer> o1,
							Entry<String, Integer> o2) {
						return o2.getValue().compareTo(
								o1.getValue());
					}
				});
		ArrayList<String> results = new ArrayList<String>();
		for (int i = 0; i < list.size(); i++) {
			results.add(list.get(i).getKey());
		}
		return results;
	}
	public static ArrayList<Integer> rankDescend(double[] v) {
		Map<Integer, Double> map = new HashMap<Integer, Double>();
		for (int i = 0; i < v.length; i++) {
			map.put(i, v[i]);
		}
		return rankDescend(map);
	}
	public static TreeSet<Integer> factors(int val) {
		TreeSet<Integer> factors = new TreeSet<Integer>();
		for(int i = 2; i < val/2; i++){
			if(val % i == 0){
				factors.add(i);
				factors.add(val/i);
			}
		}
		factors.add(val);
		return factors;
	}
	public static String getTop(HashMap<String, Double> map){
		String key = null;
		double val = 0;
		for(Entry<String, Double> entry : map.entrySet()){
			if(entry.getValue() > val){
				val = entry.getValue();
				key = entry.getKey();
			}
		}
		return key;
	}

	public static double precision(Set<String> set_true, Set<String> set_predicted){
		double tp = 0;
		for(String s : set_true)
			if(set_predicted.contains(s))
				tp++;
		double pre = tp / set_predicted.size();
		if(Double.isNaN(pre))
			pre = 0;
		return pre;
	}
	public static double recall(Set<String> set_true, Set<String> set_predicted){
		double tp = 0;
		for(String s : set_true)
			if(set_predicted.contains(s))
				tp++;
		double rec = tp / set_true.size();
		if(Double.isNaN(rec))
			rec = 0;
		return rec;
	}
	public static double f1(Set<String> s_true, Set<String> s_predicted){
		double pre = precision(s_true, s_predicted);
		double rec = recall(s_true, s_predicted);
		double f1 = 2 * pre * rec / (pre + rec);
		if(Double.valueOf(f1).isNaN())
			f1 = 0;
		return f1;
	}
}
