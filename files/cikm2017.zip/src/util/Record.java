package util;

import java.util.HashSet;

public class Record implements Comparable<Record> {
	private int time;
	private int val;
	public HashSet<Integer> L_set;

	public Record(int time, int val) {
		this.time = time;
		this.val = val;
	}
	public Record(int time, int val, HashSet<Integer> L_set) {
		this.time = time;
		this.val = val;
		this.L_set = L_set;
	}
	public int compareTo(Record o) {
		if (time < o.time)
			return -1;
		else
			return 1;
	}

	public String toString() {
		return time + "\t" + val + "\t" + L_set.toString();
	}
	public int getT() {
		return time;
	}
	public int getV() {
		return val;
	}
	public boolean isOutlier(){
		if(L_set.size() == 0)
			return false;
		for(int L : L_set){
			if(L > 0)
				return false;
		}
		return true;
	}
}
