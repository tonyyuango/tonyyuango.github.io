package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.Set;


public class Evaluation {
	private static boolean isCovered(int t, HashMap<Integer, HashSet<Integer>> L_l_set){
		for (Entry<Integer, HashSet<Integer>> entry : L_l_set.entrySet()) {
			int L = entry.getKey();
			if (entry.getValue().contains(t % L)) {
				return true;
			}
		}
		return false;
	}
	public static double evaluateO(ArrayList<Record> records, HashMap<Integer, HashSet<Integer>> L_l_set)
			throws InterruptedException {
		int l_cnt = 0;
		for(Entry<Integer, HashSet<Integer>> entry : L_l_set.entrySet()){
			l_cnt += entry.getValue().size();
		}
		if(l_cnt == 0)
			return 0;
		Set<String> O_true = new HashSet<String>();
		Set<String> O_predicted = new HashSet<String>();
		for (Record r : records) {
			if(r.getV() > 0){
				if(r.isOutlier() == true)
					O_true.add(String.valueOf(r.getT()));
				if(isCovered(r.getT(), L_l_set) == false)
					O_predicted.add(String.valueOf(r.getT()));
			}
		}
//		System.out.println(O_true.size()+"\t"+O_predicted.size());
//		System.out.println(Utility.precision(O_true, O_predicted)+"\t"+Utility.recall(O_true, O_predicted));
		return Utility.f1(O_true, O_predicted);
	}
	public static double evaluateL(String[] ts_str_al,
			HashMap<Integer, HashSet<Integer>> L_l_set_predicted) throws InterruptedException {
		Set<String> L_true = new HashSet<String>();
		Set<String> L_predicted = new HashSet<String>();

		for(String ts_str : ts_str_al){
			Integer L = Integer.valueOf(ts_str.split(":")[0]);
			L_true.add(L.toString());
		}
		for (Entry<Integer, HashSet<Integer>> entry : L_l_set_predicted.entrySet()) {
			Integer L = entry.getKey();
			L_predicted.add(L.toString());
		}
		return Utility.f1(L_true, L_predicted);
	}
	public static double evaluateS(String[] ts_str_al,
			HashMap<Integer, HashSet<Integer>> L_l_set_predicted) throws InterruptedException {
		Set<String> S_true = new HashSet<String>();
		Set<String> S_predicted = new HashSet<String>();
		
		for(String ts_str : ts_str_al){
			Integer L = Integer.valueOf(ts_str.split(":")[0]);
			String[] l_str_set = ts_str.split(":")[1].split(",");
			for(String l_str : l_str_set){
				Integer l = Integer.valueOf(l_str);
				S_true.add(L+"\t"+l);
			}
		}
		for (Entry<Integer, HashSet<Integer>> entry : L_l_set_predicted.entrySet()) {
			Integer L = entry.getKey();
			for (Integer l : entry.getValue()) {
				S_predicted.add(L+"\t"+l);
			}
		}
		return Utility.f1(S_true, S_predicted);
	}
}
