package util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Random;

public class DataGenerator {
	double beta, eta;
	int n;
	Random rand;
	public DataGenerator(double beta, double eta, int n){
		rand = new Random();
		this.beta = beta;
		this.eta = eta;
		this.n = n;
	}
	public DataGenerator(double beta, double eta, int n, int seed){
		rand = new Random(seed);
		this.beta = beta;
		this.eta = eta;
		this.n = n;
	}
	/**
	 * Each string in ts_str_al is a period pattern in the form L:l_1,l_2,...
	 * @param ts_str_al
	 * @return
	 */
	public ArrayList<Record> generateSequence(String[] ts_str_al){
		int[] L_al = new int[ts_str_al.length];
		int[][] L_l_al = new int[ts_str_al.length][];
		int L_max = 0;
		for(int i = 0; i < ts_str_al.length; i++){
			String ts_str = ts_str_al[i];
			L_al[i] = Integer.valueOf(ts_str.split(":")[0]);
			if(L_al[i] > L_max)
				L_max = L_al[i];
			String[] l_str_set = ts_str.split(":")[1].split(",");
			L_l_al[i] = new int[l_str_set.length];
			for(int j = 0; j < l_str_set.length; j++){
				String l_str = l_str_set[j];
				L_l_al[i][j] = Integer.valueOf(l_str);
			}
		}
		int N = n * L_max;
		int[] O = new int[N];
		ArrayList<Record> records = new ArrayList<Record>();
		for(int t = 0; t < N; t++){
			double eta_sample = rand.nextDouble();
			HashSet<Integer> L_set = new HashSet<Integer>();
			if (eta_sample > eta){				//low sampling
				records.add(new Record(t, O[t], L_set));
			}else{
				double beta_sample = rand.nextDouble();
				for(int i = 0; i < L_al.length; i++)
					for(int j = 0; j < L_l_al[i].length; j++)
						if(t % L_al[i] == L_l_al[i][j])
							L_set.add(L_al[i]);
				if(beta_sample >= beta){			//regular
					if(L_set.size() > 0)		//belong to positive timeslots				true positive
						O[t] = 1;
					else					//belong to negative timeslots				true negative
						O[t] = -1;
				}else{						//noise
					if(L_set.size() > 0)		//belong to positive timeslots				false negative
						O[t] = -1;
					else					//belong to negative timeslots				false positive
						O[t] = 1;
				}
				if(O[t] == 1 && L_set.size() > 0 || O[t] == -1 && L_set.size() == 0){
					records.add(new Record(t, O[t], L_set));
				}else{
					HashSet<Integer> L_set_reverse = new HashSet<Integer>();
					if(L_set.size() == 0)
						L_set_reverse.add(-1);
					else
						for(int L : L_set)
							L_set_reverse.add(-L);
					records.add(new Record(t, O[t], L_set_reverse));
				}
			}
		}
		return records;
	}
}
