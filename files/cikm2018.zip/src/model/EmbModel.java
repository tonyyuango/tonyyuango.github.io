package model;

import util.Pair;
import util.Utility;

import java.io.*;
import java.text.ParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;

/**
 * Created by quanyuan on 9/25/16.
 */
public class EmbModel extends DataBase {
    static final double NEG_SAMPLING_POWER = 0.75;
    static final int neg_table_size = 10000;
    int num_negative = 5;
    double rate;
    int K = 50;
    double[][] vec_crf;
    HashSet<Pair> crfidp_true_set = new HashSet<>();
    HashSet<Pair> crfidp_syn_true_set = new HashSet<>();
    private int[] neg_table_crf, neg_table_syn;
    Random rand = new Random(100);
    int[] alias;
    double[] prob;
    public EmbModel(String dirPath, Integer cat, int K) throws IOException, InterruptedException {
        super(dirPath, cat);
        this.K = K;
    }
    void initialModel() throws IOException, InterruptedException, ParseException {
        initialDataBase();
        //construct crf-em relations
        vec_crf = new double[CRF][K];
        for(int crfid = 0; crfid < CRF; crfid++)
            vec_crf[crfid] = Utility.randVec(K, rand);

        double[] crfid_degree = new double[CRF];
        for(int lid = 0; lid < L; lid++){
            for(int i = 0; i < lid_crfid_map[lid].length; i++){
                int crfid1 = lid_crfid_map[lid][i][0];
                int crfid2 = lid_crfid_map[lid][i][1];
                crfid_degree[crfid1] += lid_weight[lid];
                crfid_degree[crfid2] += lid_weight[lid];
            }
        }
        neg_table_crf = initialNegTable(crfid_degree);
        initAliasTable();
        double[] crfid_degree_syn = new double[CRF];
        for(int lid = 0; lid < lid_weight_syn.length; lid++){
            int crfid1 = lid_crfid_syn[lid][0];
            int crfid2 = lid_crfid_syn[lid][1];
            crfid_degree_syn[crfid1] += lid_weight_syn[lid];
            crfid_degree_syn[crfid2] += lid_weight_syn[lid];
        }
        neg_table_syn = initialNegTable(crfid_degree_syn);
        for(int weight : weight_lid_set.keySet()){
            if(weight > 1){
                for(int lid : weight_lid_set.get(weight)){
                    for(int i = 0; i < lid_crfid_map[lid].length; i++)
                        crfidp_true_set.add(new Pair(lid_crfid_map[lid][i][0], lid_crfid_map[lid][i][1]));
                }
            }
        }

        for(int lid = 0; lid < lid_crfid_syn.length; lid++)
            crfidp_syn_true_set.add(new Pair(lid_crfid_syn[lid][0], lid_crfid_syn[lid][1]));


    }

    public void update(int iter_max, double rate_init) throws Exception {
        initialModel();
        rate = rate_init;
        for (int iter = 0; iter <= iter_max; iter++) {
            rate = rate_init * (1 - 1.0 * iter / (iter_max + 1));
            if (iter % 1 == 0)
                System.out.printf("iter: %d, rate: %.3f\n", iter, rate);
            for(int t = 0; t < L; t++){
                int lid = sampleLink(rand.nextDouble(), rand.nextDouble());
                for(int i = 0; i < lid_crfid_map[lid].length; i++) {
                    Pair p = new Pair(lid_crfid_map[lid][i][0], lid_crfid_map[lid][i][1]);
                    updatePair(p);
                }
                lid = Utility.sample(lid_weight_syn, rand, 1);
                updateSyn(new Pair(lid_crfid_syn[lid][0], lid_crfid_syn[lid][1]));
            }
        }
        save();
    }
    private void updateSyn(Pair pair){
        int u = pair.id1;
        int v = pair.id2;
        double[] vec_error = new double[K];
        int target = 0, label = 0;
        for(int i = 0; i <= num_negative; i++) {
            if (i == 0) {
                target = v;
                label = 1;
            } else {
                target = neg_table_syn[Math.abs(rand.nextInt(neg_table_size))];
                while(target == v || crfidp_true_set.contains(new Pair(u, target)) || crfidp_syn_true_set.contains(new Pair(u, target)))
                    target = neg_table_syn[Math.abs(rand.nextInt(neg_table_size))];
                label = 0;
            }
            double x = Utility.vectorProduct(vec_crf[u], vec_crf[target]);
            double g = (label - 1.0 / (1 + Math.exp(-x))) * rate;

            for (int k = 0; k < K; k++)
                vec_error[k] += g * vec_crf[target][k];
            for (int k = 0; k < K; k++)
                vec_crf[target][k] += g * vec_crf[u][k];
        }
        for(int k = 0; k < K; k++)
            vec_crf[u][k] += vec_error[k];
    }
    private void updatePair(Pair pair) throws InterruptedException {
        int u = pair.id1;
        int v = pair.id2;
        double[] vec_error = new double[K];
        int target = 0, label = 0;
        for(int i = 0; i <= num_negative; i++) {
            if (i == 0) {
                target = v;
                label = 1;
            } else {
                target = neg_table_crf[Math.abs(rand.nextInt(neg_table_size))];
                while(target == v || crfidp_true_set.contains(new Pair(u, target)) || crfidp_syn_true_set.contains(new Pair(u, target))) {
                    target = neg_table_crf[Math.abs(rand.nextInt(neg_table_size))];
                }
                label = 0;
            }
            double x = Utility.vectorProduct(vec_crf[u], vec_crf[target]);
            double g = (label - 1.0 / (1 + Math.exp(-x))) * rate;

            for (int k = 0; k < K; k++)
                vec_error[k] += g * vec_crf[target][k];
            for (int k = 0; k < K; k++)
                vec_crf[target][k] += g * vec_crf[u][k];
        }
        for(int k = 0; k < K; k++)
            vec_crf[u][k] += vec_error[k];
    }
    private int[] initialNegTable(double[] id_degree){
        int[] neg_table = new int[neg_table_size];
        double sum = 0, cur_sum=0, por = 0;
        for (int id = 0; id < id_degree.length; id++)
            sum += Math.pow(id_degree[id], NEG_SAMPLING_POWER);
        Integer id = 0;
        for (int k = 0; k != neg_table_size; k++) {
            if ((double) (k + 1) / neg_table_size > por) {
                cur_sum += Math.pow(id_degree[id], NEG_SAMPLING_POWER);
                por = cur_sum / sum;
                id++;
            }
            neg_table[k] = id - 1;
        }
        return neg_table;
    }
    void save() throws Exception {
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "rel_embedding_"+cat+".txt"), "UTF-8"));
        out.println(K);
        for (Integer crfid = 0; crfid < CRF; crfid++) {
            out.println(crfid_crf.get(crfid));
            out.println(Arrays.toString(vec_crf[crfid]).replace("[", "").replace("]", "").replace(",", ""));
        }
        out.close();
    }
    void read() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "rel_embedding_"+cat+".txt"), "UTF-8"));
        this.K = Integer.valueOf(in.readLine());
        vec_crf = new double[CRF][K];
        for(int i = 0; i < CRF; i++){
            int crfid = crf_crfid.get(in.readLine());
            String[] sl = in.readLine().split(" ");
            for (int j = 0; j < sl.length; j++)
                vec_crf[crfid][j] = Double.valueOf(sl[j]);
        }
    }
    void initAliasTable() {
        alias = new int[L];
        prob = new double[L];

        double[] norm_prob = new double[L];
        int[] large_block = new int[L];
        int[] small_block = new int[L];

        double sum = 0;
        int cur_small_block, cur_large_block;
        int num_small_block = 0, num_large_block = 0;

        for (int k = 0; k != L; k++)
            sum += lid_weight[k];
        for (int k = 0; k != L; k++)
            norm_prob[k] = lid_weight[k] * L / sum;

        for (int k = L - 1; k >= 0; k--) {
            if (norm_prob[k]<1)
                small_block[num_small_block++] = k;
            else
                large_block[num_large_block++] = k;
        }

        while (num_small_block != 0 && num_large_block != 0) {
            cur_small_block = small_block[--num_small_block];
            cur_large_block = large_block[--num_large_block];
            prob[cur_small_block] = norm_prob[cur_small_block];
            alias[cur_small_block] = cur_large_block;
            norm_prob[cur_large_block] = norm_prob[cur_large_block] + norm_prob[cur_small_block] - 1;
            if (norm_prob[cur_large_block] < 1)
                small_block[num_small_block++] = cur_large_block;
            else
                large_block[num_large_block++] = cur_large_block;
        }

        while (num_large_block != 0)
            prob[large_block[--num_large_block]] = 1;
        while (num_small_block != 0)
            prob[small_block[--num_small_block]] = 1;
    }
    int sampleLink(double rand_value1, double rand_value2)
    {
        int k = (int) (L * rand_value1);
        return rand_value2 < prob[k] ? k : alias[k];
    }
}
