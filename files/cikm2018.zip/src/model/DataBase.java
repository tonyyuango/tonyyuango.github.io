package model;

import edu.mit.jwi.IDictionary;
import edu.mit.jwi.item.IIndexWord;
import edu.mit.jwi.item.IWord;
import edu.mit.jwi.item.IWordID;
import edu.mit.jwi.item.POS;
import util.Pair;
import util.Sent;
import util.Utility;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.*;

/**
 * Created by quanyuan on 10/25/16.
 */
public class DataBase {
    static String dictPath = "/Users/quanyuan/Dropbox/workspace/jar/WordNet-3.0/dict/";
    String dirPath;
    Integer cat;
    final static int defCnt = 10000000;
    int CRF, EM, C, M, E, F, RF, R, D, L;
    //index
    HashMap<String, Integer> crf_crfid = new HashMap<>();
    HashMap<Integer, String> crfid_crf = new HashMap<>();
    HashMap<String, Integer> em_emid = new HashMap<>();
    HashMap<Integer, String> emid_em = new HashMap<>();

    HashMap<String, Integer> c_cid = new HashMap<>();
    HashMap<Integer, String> cid_c = new HashMap<>();
    HashMap<String, Integer> m_mid = new HashMap<>();
    HashMap<Integer, String> mid_m = new HashMap<>();
    HashMap<String, Integer> e_eid = new HashMap<>();
    HashMap<Integer, String> eid_e = new HashMap<>();
    HashMap<String, Integer> f_fid = new HashMap<>();
    HashMap<Integer, String> fid_f = new HashMap<>();
    HashMap<String, Integer> r_rid = new HashMap<>();
    HashMap<Integer, String> rid_r = new HashMap<>();
    HashMap<String, Integer> rf_rfid = new HashMap<>();
    HashMap<Integer, String> rfid_rf = new HashMap<>();
    HashMap<String, Integer> st_stid = new HashMap<>();
    HashMap<Integer, String> stid_st = new HashMap<>();

    //mapping
    int[] emid_eid, emid_mid;
    int[] crfid_cid, crfid_rid, crfid_fid, crfid_rfid;

    HashMap<Integer, String> stid_content = new HashMap<>();
    HashMap<Integer, Sent> stid_elements = new HashMap<>();

    //links
    int[][][] lid_crfid_map;
    double[] lid_weight;
    String[] lid_stidstid;  //link-st1,st2
    int lid = 0;

    int[][] lid_crfid_syn;
    double[] lid_weight_syn;

    HashSet<Pair> cidp_syn_set = new HashSet<>();
    ArrayList<Pair> crfidp_syn_al = new ArrayList<>();  //synonym crfid
    HashSet<Pair> crfidp_form_set = new HashSet<>();
    HashMap<Integer, HashMap<Integer, HashMap<Integer, Integer>>> crfid_eid_emid_cnt = new HashMap<>();
    HashMap<Integer, Integer> crfid_cnt = new HashMap<>();
    HashMap<Integer, HashSet<Integer>> weight_lid_set = new HashMap<>();

    public DataBase(String dirPath, Integer cat){
        this.dirPath = dirPath;
        this.cat = cat;
    }
    protected void initialDataBase() throws IOException, InterruptedException {
        readFile();
        normalizeWeight();
        basicCount();
        getCRFCRFLink();
        System.out.println(toString());
    }
    public void readFile() throws IOException, InterruptedException {
        emid_eid = new int[defCnt];
        emid_mid = new int[defCnt];
        crfid_cid = new int[defCnt];
        crfid_rid = new int[defCnt];
        crfid_fid = new int[defCnt];
        crfid_rfid = new int[defCnt];
        lid_crfid_map = new int[defCnt][][];
        lid_weight = new double[defCnt];
        lid_stidstid = new String[defCnt];
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "stst_cnt_crf_"+cat+".txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = s.split("\t");
            int[][] crfid_map = new int[10][2];
            int k = 0;
            for(int i = 3; i < sl.length; i++){
//                System.out.println(sl[i]);
                String[] tl = sl[i].split(":::");
                if(tl[0].contains("null") || tl[1].contains("null"))
                    continue;
                for(int j = 0; j < 2; j++){
                    int crfid = Utility.getID(tl[j], crf_crfid, crfid_crf);
                    int cid = Utility.getID(tl[j].split("::")[0], c_cid, cid_c);
                    int rid = Utility.getID(tl[j].split("::")[1], r_rid, rid_r);
                    int fid = Utility.getID(tl[j].split("::")[2], f_fid, fid_f);
                    int rfid = Utility.getID(tl[j].split("::")[1]+"::"+tl[j].split("::")[2], rf_rfid, rfid_rf);
                    crfid_cid[crfid] = cid;
                    crfid_rid[crfid] = rid;
                    crfid_fid[crfid] = fid;
                    crfid_rfid[crfid] = rfid;
                    crfid_map[k][j] = crfid;
                }
                k++;
            }
            if(k > 0){
                int stid1 = Utility.getID(sl[0], st_stid, stid_st);
                int stid2 = Utility.getID(sl[1], st_stid, stid_st);
                lid_crfid_map[lid] = new int[k][2];
                for(int l = 0; l < k; l++)
                    for(int j = 0; j < 2; j++)
                        lid_crfid_map[lid][l][j] = crfid_map[l][j];
                int w = Integer.valueOf(sl[2]);
                lid_weight[lid] = w;
                if(!weight_lid_set.containsKey(w))
                    weight_lid_set.put(w, new HashSet<>());
                weight_lid_set.get(w).add(lid);
                lid_stidstid[lid] = stid1+":"+stid2;
                lid++;
            }
        }
        in.close();
        L = lid;
        lid_crfid_map = Arrays.copyOf(lid_crfid_map, L);
        lid_weight = Arrays.copyOf(lid_weight, L);
        lid_stidstid = Arrays.copyOf(lid_stidstid, L);
        CRF = crf_crfid.size();
        C = c_cid.size();
        R = r_rid.size();
        F = f_fid.size();
        RF = rf_rfid.size();
        crfid_cid = Arrays.copyOf(crfid_cid, CRF);
        crfid_rid = Arrays.copyOf(crfid_rid, CRF);
        crfid_fid = Arrays.copyOf(crfid_fid, CRF);
        crfid_rfid = Arrays.copyOf(crfid_rfid, CRF);

        in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data_cat_new_"+cat+".txt"), "UTF-8"));
        while ((s = in.readLine()) != null) {
            if (!s.equals("*************"))
                wait();
            String[] sl = in.readLine().split("\t");
            String[] fname_al = sl[0].split("_");
            String st = sl[0]+"_"+sl[2];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            if(!st_stid.containsKey(st)){
                in.readLine();
                for (int i = 0; i < tpCnt + wCnt; i++)
                    in.readLine();
                continue;
            }
            String e = fname_al[0]+"_"+fname_al[1];
            Integer stid = Utility.getID(st, st_stid, stid_st);
            String content = in.readLine();
            stid_content.put(stid, content);
            ArrayList<Integer> crfid_al = new ArrayList<>();
            ArrayList<Integer> emid_al = new ArrayList<>();
            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String c = sl[0].split(":")[0];
                String r = sl[0].split(":")[1];
                String f = sl[1];
                String m = sl[2];
                String rf = r + "::"+f;
                String crf = c+"::"+rf;
                String em = e + "::"+m;
//                if(invalid_concept.contains(c))
//                    continue;
                if(!crf_crfid.containsKey(crf))
                    continue;
                int eid = Utility.getID(e, e_eid, eid_e);
                int mid = Utility.getID(m, m_mid, mid_m);
                int emid = Utility.getID(em, em_emid, emid_em);
                int crfid = Utility.getID(crf, crf_crfid, crfid_crf);
                emid_eid[emid] = eid;
                emid_mid[emid] = mid;
                crfid_al.add(crfid);
                emid_al.add(emid);
            }
            stid_elements.put(stid, new Sent(crfid_al, emid_al));
            for (int i = 0; i < wCnt; i++)
                in.readLine();
        }
        in.close();
        EM = em_emid.size();
        D = stid_elements.size();
        M = m_mid.size();
        E = e_eid.size();
        emid_eid = Arrays.copyOf(emid_eid, EM);
        emid_mid = Arrays.copyOf(emid_mid, EM);
//        System.out.println(f_fid.keySet());
//        wait();
    }
    private void basicCount(){
        for(Sent elem : stid_elements.values()){
            for(int i = 0; i < elem.size; i++){
                int crfid = elem.crfid_al.get(i);
                int emid = elem.emid_al.get(i);
                int eid = emid_eid[emid];
                if(!crfid_eid_emid_cnt.containsKey(crfid))
                    crfid_eid_emid_cnt.put(crfid, new HashMap<>());
                if(!crfid_eid_emid_cnt.get(crfid).containsKey(eid))
                    crfid_eid_emid_cnt.get(crfid).put(eid, new HashMap<>());
                Utility.recordCnt(emid, 1, crfid_eid_emid_cnt.get(crfid).get(eid));
            }
        }
        for(Map.Entry<Integer, Sent> entry : stid_elements.entrySet()) {
            Sent elem = entry.getValue();
            for(int i = 0; i < elem.size; i++){
                int crfid = elem.crfid_al.get(i);
                Utility.recordCnt(crfid, 1, crfid_cnt);
            }
        }
    }
    private void normalizeWeight() throws InterruptedException {
        for(int weight : weight_lid_set.keySet()){
            double weight_sum = 0;
            for(int lid : weight_lid_set.get(weight))
                weight_sum += weight;
            for(int lid : weight_lid_set.get(weight))
                lid_weight[lid] /= weight_sum;
        }
    }
    private void getCRFCRFLink() throws IOException, InterruptedException {
        HashMap<Integer, HashSet<Integer>> cid_emid_set = new HashMap<>();
        for(Map.Entry<Integer, HashMap<Integer, HashMap<Integer, Integer>>> entry : crfid_eid_emid_cnt.entrySet()){
            int cid = crfid_cid[entry.getKey()];
            if(!cid_emid_set.containsKey(cid))
                cid_emid_set.put(cid, new HashSet<>());
            for(HashMap<Integer, Integer> emEntry : entry.getValue().values())
                cid_emid_set.get(cid).addAll(emEntry.keySet());
        }
        HashMap<Integer, HashSet<Integer>> cid_crfid_set = new HashMap<>();
        for(int crfid = 0; crfid < CRF; crfid++){
            int cid = crfid_cid[crfid];
            if(!cid_crfid_set.containsKey(cid))
                cid_crfid_set.put(cid, new HashSet<>());
            cid_crfid_set.get(cid).add(crfid);
        }
        IDictionary dict;
        URL url = new URL("file", null, dictPath);
        dict = new edu.mit.jwi.Dictionary(url);
        dict.open();
        HashMap<Integer, HashSet<String>> cid_sync_set = new HashMap<>();
        for(int cid = 0; cid < C; cid++)
            cid_sync_set.put(cid, getSynonyms(cid_c.get(cid), dict));

        lid = 0;
        lid_crfid_syn = new int[defCnt][2];
        lid_weight_syn = new double[defCnt];
        for(int cid1 = 0; cid1 < C; cid1++) {
            for (int cid2 = cid1 + 1; cid2 < C; cid2++) {
                if (cid_sync_set.get(cid1).contains(cid_c.get(cid2)) || cid_sync_set.get(cid2).contains(cid_c.get(cid1))) {
                    HashSet<Integer> emid_common_set = Utility.commonEntryI(cid_emid_set.get(cid1), cid_emid_set.get(cid2));
                    if(emid_common_set.size() > 0) {
                        cidp_syn_set.add(new Pair(cid1, cid2));

                        for (Integer crfid1 : cid_crfid_set.get(cid1)) {
                            for (Integer crfid2 : cid_crfid_set.get(cid2)) {
                                if (crfid_rfid[crfid1] == crfid_rfid[crfid2]) {
                                    Pair pair = new Pair(crfid1, crfid2);
                                    crfidp_syn_al.add(pair);
                                    lid_crfid_syn[lid] = new int[]{pair.id1, pair.id2};
                                    lid_weight_syn[lid] = emid_common_set.size();
                                    lid++;
//                                    System.out.println("syn: "+crfid_crf.get(crfid1)+"\t"+crfid_crf.get(crfid2)+"\t"+em_cnt);
                                }
                            }
                        }
                    }
                }
            }
        }
        lid_crfid_syn = Arrays.copyOf(lid_crfid_syn, lid);
        lid_weight_syn = Arrays.copyOf(lid_weight_syn, lid);
        Utility.normalizeL1(lid_weight_syn);
        for(int cid1 = 0; cid1 < C; cid1++){
            for(String c2 : getOtherForm(cid_c.get(cid1), dict)){
                if(!c_cid.containsKey(c2)) continue;
                int cid2 = c_cid.get(c2);
                for (int crfid1 : cid_crfid_set.get(cid1)) {
                    for (int crfid2 : cid_crfid_set.get(cid2)) {
                        if(crfid1 == crfid2) continue;
                        if (crfid_rfid[crfid1] == crfid_rfid[crfid2]) {
                            Pair pair = new Pair(crfid1, crfid2);
                            crfidp_form_set.add(pair);
                        }
                    }
                }
            }
        }
    }
    private HashSet<String> getSynonyms(String word_str, IDictionary dict){
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(word_str, POS.VERB), dict.getIndexWord(word_str, POS.NOUN)};
        HashSet<String> syn_set = new HashSet<>();
        syn_set.add(word_str);
        for(IIndexWord idxWord : idxWord_al){       //for each POS
            if(idxWord == null)
                continue;
            for(IWordID wordID : idxWord.getWordIDs()){     //for each current word
                IWord word = dict.getWord(wordID);
                for (IWord w : word.getSynset().getWords()) {       //add its synonyms
                    if(w.getLemma().contains("_"))
                        continue;
                    syn_set.add(w.getLemma());
                }
                for(IWordID wordID_rel : word.getRelatedWords()){       //for each related word of current word
                    IWord word_rel = dict.getWord(wordID_rel);
                    if(word_rel.getLemma().contains("_") || word_rel.getLemma().length() < 2 || word.getLemma().length() < 2 || !word_rel.getLemma().substring(0, 2).equals(word.getLemma().substring(0, 2))) continue;
                    if(!(word_rel.getPOS() == POS.VERB || word_rel.getPOS() == POS.NOUN))continue;
                    syn_set.add(word_rel.getLemma());       //add it as synonyms
                    for (IWord w : word_rel.getSynset().getWords()) {       //for each synonym of current related word
                        if(w.getLemma().contains("_"))
                            continue;
                        syn_set.add(w.getLemma());
                    }
                }
            }
        }
        return syn_set;
    }
    private HashSet<String> getOtherForm(String word_str, IDictionary dict){
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(word_str, POS.VERB), dict.getIndexWord(word_str, POS.NOUN)};
        HashSet<String> form_set = new HashSet<>();
        for(IIndexWord idxWord : idxWord_al){       //for each POS
            if(idxWord == null)
                continue;
            for(IWordID wordID : idxWord.getWordIDs()){     //for each current word
                IWord word = dict.getWord(wordID);
                for(IWordID wordID_rel : word.getRelatedWords()){       //for each related word of current word
                    IWord word_rel = dict.getWord(wordID_rel);
                    if(word_rel.getLemma().contains("_") || word_rel.getLemma().length() < 2 || word.getLemma().length() < 2 || !word_rel.getLemma().substring(0, 2).equals(word.getLemma().substring(0, 2))) continue;
                    if(!(word_rel.getPOS() == POS.VERB || word_rel.getPOS() == POS.NOUN))continue;
                    form_set.add(word_rel.getLemma());       //add it as synonyms
                }
            }
        }
        return form_set;
    }

    @Override
    public String toString() {
        return "DataBase{" +
                "cat=" + cat +
                ", CRF=" + CRF +
                ", EM=" + EM +
                ", C=" + C +
                ", M=" + M +
                ", E=" + E +
                ", F=" + F +
                ", RF=" + RF +
                ", R=" + R +
                ", D=" + D +
                ", L=" + L +
                '}';
    }
}
