package model;

import util.Utility;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by quanyuan on 2/16/17.
 */
public class Slot {
    double[] emid_cnt;
    int size = 0;
    HashMap<Integer, Integer> crfid_cnt = new HashMap<>();
    public Slot(HashMap<Integer, Integer> crfid_cnt, HashMap<Integer, HashMap<Integer, HashMap<Integer, Integer>>> crfid_eid_emid_cnt, int EM) {
        this.crfid_cnt = crfid_cnt;
        this.emid_cnt = new double[EM];
        for (Integer crfid : crfid_cnt.keySet()) {
            for (Integer eid : crfid_eid_emid_cnt.get(crfid).keySet()) {
                for (Integer emid : crfid_eid_emid_cnt.get(crfid).get(eid).keySet()) {
                    emid_cnt[emid] += crfid_eid_emid_cnt.get(crfid).get(eid).get(emid);
                    size += emid_cnt[emid];
                }
            }
        }
    }
    public double getSim(Slot o) {
        double sim = Utility.cosine_full(this.emid_cnt, o.emid_cnt);
        return sim;
    }
    public void merge(Slot o) {
        for (int crfid : o.crfid_cnt.keySet()) {
            crfid_cnt.put(crfid, crfid_cnt.getOrDefault(crfid, 0) + o.crfid_cnt.get(crfid));
        }
        for (int emid = 0; emid < emid_cnt.length; emid++) {
            if (o.emid_cnt[emid] != 0) {
                emid_cnt[emid] += o.emid_cnt[emid];
                size += o.emid_cnt[emid];
            }
        }
    }
    public void printResult(HashMap<Integer, String> crfid_crf, HashMap<Integer, String> eid_e, HashMap<Integer, String> emid_em, HashMap<Integer, HashMap<Integer, HashMap<Integer, Integer>>> crfid_eid_emid_cnt, int E) {
        ArrayList<Integer> crfid_rank = Utility.rankDescendII(crfid_cnt);
        System.out.println("slot size: " + size);
        for (Integer crfid : crfid_rank) {
            System.out.println("\t" + crfid_crf.get(crfid) + "\t\t" + crfid_cnt.get(crfid));
            for (int eid = 0; eid < E; eid++) {
                if (crfid_eid_emid_cnt.get(crfid).containsKey(eid) && crfid_eid_emid_cnt.get(crfid).get(eid).size() > 0) {
                    System.out.print("\t\te: " + eid_e.get(eid));
                    ArrayList<Integer> emid_rank = Utility.rankDescendII(crfid_eid_emid_cnt.get(crfid).get(eid));
                    for (int i = 0; i < 3 && i < emid_rank.size(); i++) {
                        System.out.print("\t" + emid_em.get(emid_rank.get(i)).split("::")[1] + " (" + crfid_eid_emid_cnt.get(crfid).get(eid).get(emid_rank.get(i)) + ")");
                    }
                    System.out.println();
                }
            }
        }
    }
}
