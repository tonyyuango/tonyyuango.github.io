package model;

import com.clust4j.algo.AffinityPropagation;
import com.clust4j.algo.AffinityPropagationParameters;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import smile.clustering.SpectralClustering;
import util.Pair;
import util.PairSim;
import util.Utility;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by quanyuan on 10/7/16.
 */
public class FinalClustering extends EmbModel {
    double pos = 0.8;
    double value_sim_threshold = 0;
    double other_sim_threshold = 0.2;
    double sim_threshold = 0.2;
    double[][] crfid_crfid_sim;
    HashMap<Integer, HashSet<Integer>> cid_crfid_set = new HashMap<>();
    HashSet<Integer> crfid_not_consider = new HashSet<>();
    public FinalClustering(String dirPath, Integer cat, int K) throws IOException, InterruptedException {
        super(dirPath, cat, K);
    }
    private void initialCluster() throws ParseException, InterruptedException, IOException {
        initialDataBase();
        read();
        for(int crfid = 0; crfid < CRF; crfid++){
            if(crfid_crf.get(crfid).contains("null") || crfid_eid_emid_cnt.get(crfid).size() < 2)
                crfid_not_consider.add(crfid);
            int cid = crfid_cid[crfid];
            if(!cid_crfid_set.containsKey(cid))
                cid_crfid_set.put(cid, new HashSet<>());
            cid_crfid_set.get(cid).add(crfid);
        }
        initialSim();
    }
    private void initialSim() throws ParseException, InterruptedException {
        crfid_crfid_sim = new double[CRF][CRF];
        for(int crfid1 = 0; crfid1 < CRF; crfid1++) {
            crfid_crfid_sim[crfid1][crfid1] = 1;
            for (int crfid2 = crfid1 + 1; crfid2 < CRF; crfid2++) {
                if (crfid_fid[crfid1] != crfid_fid[crfid2]) continue;
                double sim = crfidcrfidSimARG(crfid1, crfid2);
                if(sim < 0)
                    sim = 0;
                crfid_crfid_sim[crfid1][crfid2] = sim;
                crfid_crfid_sim[crfid2][crfid1] = sim;
            }
        }


    }
    public void SC() throws ParseException, InterruptedException, IOException {
        initialCluster();
        HashMap<Integer, HashSet<Integer>> fid_crfid_set = new HashMap<>();
        for(int crfid = 0; crfid < CRF; crfid++){
            if(crfid_not_consider.contains(crfid)) continue;
            int fid = crfid_fid[crfid];
            if(!fid_crfid_set.containsKey(fid))
                fid_crfid_set.put(fid, new HashSet<>());
            fid_crfid_set.get(fid).add(crfid);
        }
        ArrayList<HashMap<Integer, Integer>> fid_crfid_id = new ArrayList<>();
        ArrayList<HashMap<Integer, Integer>> fid_id_crfid = new ArrayList<>();
        double[][][] fid_W = new double[F][][];
        for(int fid = 0; fid < F; fid++) {
            fid_crfid_id.add(new HashMap<>());
            fid_id_crfid.add(new HashMap<>());
        }
        for(int fid = 0; fid < F; fid++){
            if(!fid_crfid_set.containsKey(fid)){
                fid_W[fid] = new double[0][0];
                continue;
            }
            fid_W[fid] = new double[crf_crfid.size()][crf_crfid.size()];
            for(Integer crfid1 : fid_crfid_set.get(fid)){
                for(Integer crfid2 : fid_crfid_set.get(fid)){
                    if(crfid1 >= crfid2) continue;
                    double sim = crfid_crfid_sim[crfid1][crfid2];
                    if(sim == 0)
                        continue;
                    Utility.getID(crfid1, fid_crfid_id.get(fid), fid_id_crfid.get(fid));
                    Utility.getID(crfid2, fid_crfid_id.get(fid), fid_id_crfid.get(fid));
                    int id1 = fid_crfid_id.get(fid).get(crfid1);
                    int id2 = fid_crfid_id.get(fid).get(crfid2);
                    fid_W[fid][id1][id2] = sim;
                    fid_W[fid][id2][id1] = sim;
                }
            }
        }
        for(Pair crfidp : crfidp_form_set) {
            int crfid1 = crfidp.id1;
            int crfid2 = crfidp.id2;
            if(crfid_not_consider.contains(crfid1) || crfid_not_consider.contains(crfid2)) continue;
            int fid = crfid_fid[crfid1];
            Utility.getID(crfid1, fid_crfid_id.get(fid), fid_id_crfid.get(fid));
            Utility.getID(crfid2, fid_crfid_id.get(fid), fid_id_crfid.get(fid));
            int id1 = fid_crfid_id.get(fid).get(crfid1);
            int id2 = fid_crfid_id.get(fid).get(crfid2);
            fid_W[fid][id1][id2] = 1;
            fid_W[fid][id2][id1] = 1;
        }
        for(int fid = 0; fid < F; fid++) {
            if (!fid_crfid_set.containsKey(fid)) {
                fid_W[fid] = new double[0][0];
                continue;
            }
            for(int i = 0; i < fid_crfid_id.get(fid).size(); i++)
                fid_W[fid][i] = Arrays.copyOf(fid_W[fid][i], fid_crfid_id.get(fid).size());
            fid_W[fid] = Arrays.copyOf(fid_W[fid], fid_crfid_id.get(fid).size());
        }
        HashMap<Integer, Integer> k_cnt = new HashMap<>();      //cluster size
        HashMap<Integer, HashMap<Integer, Integer>> k_crfid_cnt = new HashMap<>();      //cluster-crfid cnt
        HashSet<Integer> crfid_set_tobeadded = new HashSet<>(crfid_eid_emid_cnt.keySet());
        for (int fid = 0; fid < fid_W.length; fid++) {
            if (fid_W[fid].length == 0)
                continue;
            System.out.println("F: " + fid_f.get(fid) + "\t" + fid_W[fid].length);
            int[] id_k = spectralcluster(fid_W, fid, fid_id_crfid);
            for (int id = 0; id < id_k.length; id++)
                id_k[id] += k_cnt.size();
            //assign id to corresponding cluster
            for (int id = 0; id < id_k.length; id++) {
                Integer crfid = fid_id_crfid.get(fid).get(id);
                Integer k = id_k[id];
                if (!k_crfid_cnt.containsKey(k))
                    k_crfid_cnt.put(k, new HashMap<>());
                Utility.recordCnt(k, crfid_cnt.get(crfid), k_cnt);
                Utility.recordCnt(crfid, crfid_cnt.get(crfid), k_crfid_cnt.get(k));
                crfid_set_tobeadded.remove(crfid);
            }
        }
        for (Integer crfid : crfid_set_tobeadded) {
            if(crfid_crf.get(crfid).contains("null") || crfid_eid_emid_cnt.get(crfid).size() < 3)
                continue;
            int k = k_cnt.size();
            k_crfid_cnt.put(k, new HashMap<>());
            Utility.recordCnt(k, crfid_cnt.get(crfid), k_cnt);
            Utility.recordCnt(crfid, crfid_cnt.get(crfid), k_crfid_cnt.get(k));
        }
        int total = 0;
        for (int val : k_cnt.values()) {
            total += val;
        }
        System.out.println("total: "+total);


        ArrayList<Integer> id_rank = Utility.rankDescendII(k_cnt);
        ArrayList<Slot> slotAl = new ArrayList<Slot>();
        for (int id : id_rank) {
            if (k_cnt.get(id) <= 10) {
                continue;
            }
            Slot slot = new Slot(k_crfid_cnt.get(id), crfid_eid_emid_cnt, EM);
            boolean valid = true;
            for (Slot pre : slotAl) {
                if (pre.getSim(slot) >= 0.25) {
                    valid = false;
                }
                if (pre.getSim(slot) >= 0.75) {
                    pre.merge(slot);
                }
            }
            if (!valid) {
                continue;
            } else {
                slotAl.add(slot);
            }
        }
        Collections.sort(slotAl, (o1, o2)->o2.size - o1.size);
        for (int slotID = 0; slotID < slotAl.size(); slotID++) {
            if (slotAl.get(slotID).size <= 10) {
                break;
            }
            System.out.println("slotID: "+slotID);
            slotAl.get(slotID).printResult(crfid_crf, eid_e, emid_em, crfid_eid_emid_cnt, E);
        }
    }

    private double quality(HashMap<Integer, Integer> crfid_id, int fid_target) throws ParseException, InterruptedException {
        double measure = 0;
        for(int eid = 0; eid < E; eid++){
            ArrayList<Integer> emid_al = new ArrayList<>();
            ArrayList<Integer> fid_al = new ArrayList<>();
            ArrayList<Integer> id_al = new ArrayList<>();
            for (int crfid = 0; crfid < CRF; crfid++) {
                if(crfid_not_consider.contains(crfid)) continue;
                Integer id = crfid_id.get(crfid);
                if(id == null)
                    continue;
                int fid = crfid_fid[crfid];
                if(fid != fid_target || !crfid_eid_emid_cnt.get(crfid).containsKey(eid))
                    continue;
                for (Map.Entry<Integer, Integer> entry : crfid_eid_emid_cnt.get(crfid).get(eid).entrySet()) {
                    int emid = entry.getKey();
                    int cnt = entry.getValue();
                    for (int i = 0; i < cnt; i++) {
                        emid_al.add(emid);
                        fid_al.add(fid);
                        id_al.add(id);
                    }
                }
            }
            for(int i = 0; i < emid_al.size(); i++){
                int emid1 = emid_al.get(i);
                int fid1 = fid_al.get(i);
                int id1 = id_al.get(i);
                for(int j = i+1; j < emid_al.size(); j++){
                    int emid2 = emid_al.get(j);
                    int fid2 = fid_al.get(j);
                    int id2 = id_al.get(j);
                    if(fid1 != fid2)
                        continue;
                    double sim = 1;
                    if(emid1 != emid2)
                        sim = getEMEMSim(emid1, emid2, fid1);
                    if(id1 == id2)
                        measure += (1 - sim);
                    else
                        measure += sim;
                }
            }
        }
        return measure;
    }
    protected int getEMEMSim(int emid1, int emid2, int fid) throws InterruptedException, ParseException {
        try{
            SimpleDateFormat sdf_date = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf_time = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            if (emid1 == emid2) return 1;
            String f = fid_f.get(fid);
            String m1 = mid_m.get(emid_mid[emid1]);
            String m2 = mid_m.get(emid_mid[emid2]);
            if (m1.contains(m2) || m2.contains(m1))
                return 1;
            if (m1.contains(" ")) {
                String abbr1 = "";
                for (String comp : m1.split(" "))
                    abbr1 += comp.substring(0, 1);
                if (m2.equals(abbr1))
                    return 1;
            }
            if (m2.contains(" ")) {
                String abbr2 = "";
                for (String comp : m2.split(" "))
                    abbr2 += comp.substring(0, 1);
                if (m1.equals(abbr2))
                    return 1;
            }
            if (f.equals("DATE")) {
                Date date1 = sdf_date.parse(m1);
                Date date2 = sdf_date.parse(m2);
                int hour_diff = Math.abs((int) ((date2.getTime() - date1.getTime()) / 1000 / 60 / 60));
                if (hour_diff <= 24)
                    return 1;
            } else if (f.equals("TIME")) {
                Date date1 = sdf_time.parse(m1);
                Date date2 = sdf_time.parse(m2);
                int hour_diff = Math.abs((int) ((date2.getTime() - date1.getTime()) / 1000 / 60 / 60));
                if (hour_diff <= 8)
                    return 1;
            } else if (f.equals("MONEY")) {
                if(!m1.contains("$") || !m2.contains("$"))
                    return 0;
                while (!m1.substring(0, 1).equals("$"))
                    m1 = m1.substring(1);
                m1 = m1.substring(1);
                while (!m2.substring(0, 1).equals("$"))
                    m2 = m2.substring(1);
                m2 = m2.substring(1);
                if (m1.contains("e") && m2.contains("e")) {
                    if (!m1.split("e")[1].equals(m2.split("e")[1]))
                        return 0;
                    m1 = m1.split("e")[0];
                    m2 = m2.split("e")[0];
                }
                if (m1.contains("e") && !m2.contains("e") || !m1.contains("e") && m2.contains("e"))
                    return 0;
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.1)
                    return 1;
            } else if (f.equals("PERCENT")) {
                while (!m1.substring(0, 1).equals("%"))
                    m1 = m1.substring(1);
                m1 = m1.substring(1);
                while (!m2.substring(0, 1).equals("%"))
                    m2 = m2.substring(1);
                m2 = m2.substring(1);
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.1)
                    return 1;
            } else if (f.equals("NUMBER")) {
                while (!m1.substring(0, 1).matches("[0-9]")) {
                    m1 = m1.substring(1);
                }
                while (!m2.substring(0, 1).matches("[0-9]")) {
                    m2 = m2.substring(1);
                }
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
//            System.out.println(v1+"\t"+v2+"\t"+Math.abs(v2 - v1) / Math.max(v1, v2));
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.1)
                    return 1;
            }}catch(Exception e){
            return 0;
        }
        return 0;
    }

    private int[] spectralcluster(double[][][] fid_W, int fid, ArrayList<HashMap<Integer, Integer>> fid_id_crfid) throws ParseException, InterruptedException {
        int max = fid_W[fid].length > 50 ? 50 : fid_W[fid].length;
        if (fid_W[fid].length < 10) {
            max = 3;
        }
        max = Math.min(max, fid_W[fid].length - 1);
//        int max = fid_W[fid].length / 3;
        int step_cnt = 0;
        int[] label_al = new int[fid_W[fid].length];

        double metric_min = Double.MAX_VALUE;
        for(int k = 1; k <= max; k++){
            int[] label_al_k = null;
            if(k == 1){
                label_al_k = new int[fid_W[fid].length];
            }else {
                SpectralClustering sc = new SpectralClustering(fid_W[fid], k);
                label_al_k = sc.getClusterLabel();
            }
            HashMap<Integer, Integer> crfid_clusterid = new HashMap<>();
            for(int id = 0; id < label_al_k.length; id++){
                int crfid = fid_id_crfid.get(fid).get(id);
                int clusterid = label_al_k[id];
                crfid_clusterid.put(crfid, clusterid);
            }
            double metric = quality(crfid_clusterid, fid);
            if(metric < metric_min){
                metric_min = metric;
                label_al = Arrays.copyOf(label_al_k, label_al_k.length);
                step_cnt = 0;
            }
            System.out.println(k+"\t\t" + metric);
            step_cnt++;
            if(step_cnt == 30)
                break;
        }
        return label_al;
    }
    double crfidcrfidSimARG(int crfid1, int crfid2) throws ParseException, InterruptedException {
        if (crfid1 == crfid2 || crfid_fid[crfid1] != crfid_fid[crfid2])
            return 0;
        double sim = Utility.cosine_full(vec_crf[crfid1], vec_crf[crfid2]);
//        double sim_other = crfidcrfidSimOther(crfid1, crfid2);
//        if(sim_other != -1 && sim_other < other_sim_threshold)
//            sim = 0;
        return sim;
    }
    public static void main(String[] args) throws Exception {
        String dirPath = "";
        int K = 50;
        int iter_max = 200;
        double rate_init = 0.025;
        int cat = 4;            //0: acquire; 1. earthquake; 2. announce; 3. crash; 4. bombing
        FinalClustering c = new FinalClustering(dirPath, cat, K);
        c.update(iter_max, rate_init);
        c.SC();
    }
}
