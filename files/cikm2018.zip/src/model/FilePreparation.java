package model;

import edu.mit.jwi.IDictionary;
import edu.mit.jwi.item.IIndexWord;
import edu.mit.jwi.item.IWord;
import edu.mit.jwi.item.IWordID;
import edu.mit.jwi.item.POS;
import util.IDPair;
import util.Sent;
import util.Utility;

import java.io.*;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by quanyuan on 10/25/16.
 */
public class FilePreparation {
    static String dictPath = "../WordNet-3.0/dict/";
    String dirPath;
    Integer cat;
    final static int defCnt = 10000000;
    int CRF, EM, C, M, E, F, RF, R, D, L;
    //index
    HashMap<String, Integer> crf_crfid = new HashMap<>();
    HashMap<Integer, String> crfid_crf = new HashMap<>();
    HashMap<String, Integer> em_emid = new HashMap<>();
    HashMap<Integer, String> emid_em = new HashMap<>();

    HashMap<String, Integer> c_cid = new HashMap<>();
    HashMap<Integer, String> cid_c = new HashMap<>();
    HashMap<String, Integer> m_mid = new HashMap<>();
    HashMap<Integer, String> mid_m = new HashMap<>();
    HashMap<String, Integer> e_eid = new HashMap<>();
    HashMap<Integer, String> eid_e = new HashMap<>();
    HashMap<String, Integer> f_fid = new HashMap<>();
    HashMap<Integer, String> fid_f = new HashMap<>();
    HashMap<String, Integer> r_rid = new HashMap<>();
    HashMap<Integer, String> rid_r = new HashMap<>();
    HashMap<String, Integer> rf_rfid = new HashMap<>();
    HashMap<Integer, String> rfid_rf = new HashMap<>();
    HashMap<String, Integer> st_stid = new HashMap<>();
    HashMap<Integer, String> stid_st = new HashMap<>();

    //mapping
    int[] emid_eid, emid_mid;
    int[] crfid_cid, crfid_rid, crfid_fid, crfid_rfid;

    HashMap<Integer, String> stid_content = new HashMap<>();
    HashMap<Integer, Sent> stid_elements = new HashMap<>();

    //links
    int[][][] lid_crfid_map;
    int[][] lid_emid_map;
    double[] lid_weight;
    String[] lid_stidstid;  //link-st1,st2
    int lid = 0;

    HashMap<Integer, HashMap<Integer, HashMap<Integer, Integer>>> crfid_eid_emid_cnt = new HashMap<>();
    HashMap<Integer, Integer> crfid_cnt = new HashMap<>();
    HashMap<String, String> c_ori_nor = new HashMap<>();
    HashMap<String, String> m_f_ori_nor = new HashMap<>();
    HashMap<String, String> m_m_ori_nor = new HashMap<>();
    IDictionary dict;

    public FilePreparation(String dirPath, int cat) throws IOException, InterruptedException {
        this.dirPath = dirPath;
        this.cat = cat;
        URL url = new URL("file", null, dictPath);
        dict = new edu.mit.jwi.Dictionary(url);
        dict.open();
        c_ori_nor.put("dead", "die");
        c_ori_nor.put("death", "die");
        c_ori_nor.put("extent", "extend");
        c_ori_nor.put("shooting", "shoot");
        c_ori_nor.put("discussion", "discuss");
        c_ori_nor.put("explanation", "explain");
        c_ori_nor.put("resolution", "resolve");
        c_ori_nor.put("setting", "set");
        c_ori_nor.put("injure", "injury");
        c_ori_nor.put("evaluation", "evaluate");
        c_ori_nor.put("contribution", "contribute");
        c_ori_nor.put("identification", "identify");
        c_ori_nor.put("meaning", "mean");
        c_ori_nor.put("injury", "injure");
        c_ori_nor.put("separatist", "separate");
        c_ori_nor.put("hunting", "hunt");
        c_ori_nor.put("meeting", "meet");
        c_ori_nor.put("suspension", "suspend");
        c_ori_nor.put("prevention", "prevent");
        c_ori_nor.put("announcement", "announce");
        c_ori_nor.put("addition", "add");
        c_ori_nor.put("agreement", "agree");
        c_ori_nor.put("mourning", "mourn");
        c_ori_nor.put("documentation", "document");
        c_ori_nor.put("spreading", "spread");
        c_ori_nor.put("investment", "invest");
        c_ori_nor.put("analysis", "analyze");
        c_ori_nor.put("monitoring", "monitor");
        c_ori_nor.put("intention", "intend");
        c_ori_nor.put("extend", "extent");
        c_ori_nor.put("planning", "plan");
        c_ori_nor.put("cancellation", "cancel");
        c_ori_nor.put("selection", "select");
        c_ori_nor.put("exposure", "expose");
        c_ori_nor.put("offering", "offer");
        c_ori_nor.put("difference", "differ");
        c_ori_nor.put("consideration", "consider");
        c_ori_nor.put("switching", "switch");
        c_ori_nor.put("flight", "flee");
        c_ori_nor.put("treatment", "treat");
        c_ori_nor.put("scanning", "scan");
        c_ori_nor.put("killing", "kill");
        c_ori_nor.put("association", "associate");
        c_ori_nor.put("believe", "belief");
        c_ori_nor.put("measurement", "measure");
        c_ori_nor.put("opposition", "oppose");
        c_ori_nor.put("involvement", "involve");
        c_ori_nor.put("adoption", "adopt");
        c_ori_nor.put("commission", "commit");
        c_ori_nor.put("acquisition", "acquire");
        c_ori_nor.put("relationship", "relation");
        c_ori_nor.put("listing", "list");
        c_ori_nor.put("destruction", "destroy");
        c_ori_nor.put("situation", "situate");
        c_ori_nor.put("creation", "create");
        c_ori_nor.put("completion", "complete");
        c_ori_nor.put("descend", "descent");
        c_ori_nor.put("detection", "detect");
        c_ori_nor.put("participate", "participant");
        c_ori_nor.put("reaction", "react");
        c_ori_nor.put("contain", "content");
        c_ori_nor.put("committee", "commit");
        c_ori_nor.put("decision", "decide");
        c_ori_nor.put("signify", "sign");
        c_ori_nor.put("procedure", "proceed");
        c_ori_nor.put("transportation", "transport");
        c_ori_nor.put("standing", "stand");
        c_ori_nor.put("fighting", "fight");
        c_ori_nor.put("descent", "descend");
        c_ori_nor.put("marketing", "market");
        c_ori_nor.put("speech", "speak");
        c_ori_nor.put("buying", "buy");
        c_ori_nor.put("information", "inform");
        c_ori_nor.put("diversification", "diversify");
        c_ori_nor.put("operation", "operate");
        c_ori_nor.put("insurance", "insure");
        c_ori_nor.put("engagement", "engage");
        c_ori_nor.put("excellence", "excel");
        c_ori_nor.put("reunite", "reunion");
        c_ori_nor.put("accounting", "account");
        c_ori_nor.put("repetition", "repeat");
        c_ori_nor.put("briefing", "brief");
        c_ori_nor.put("participant", "participate");
        c_ori_nor.put("coordination", "coordinate");
        c_ori_nor.put("scrutinize", "scrutiny");
        c_ori_nor.put("presentation", "present");
        c_ori_nor.put("assessment", "assess");
        c_ori_nor.put("differentiate", "difference");
        c_ori_nor.put("transmission", "transmit");
        c_ori_nor.put("criticise", "criticism");
        c_ori_nor.put("warning", "warn");
        c_ori_nor.put("donation", "donate");
        c_ori_nor.put("criticism", "criticise");
        c_ori_nor.put("shipment", "ship");
        c_ori_nor.put("invitation", "invite");
        c_ori_nor.put("collection", "collect");
        c_ori_nor.put("finding", "find");
        c_ori_nor.put("sharing", "share");
        c_ori_nor.put("assurance", "assure");
        c_ori_nor.put("celebration", "celebrate");
        c_ori_nor.put("spending", "spend");
        c_ori_nor.put("failure", "fail");
        c_ori_nor.put("flying", "fly");
        c_ori_nor.put("neighborhood", "neighbor");
        c_ori_nor.put("confusion", "confuse");
        c_ori_nor.put("beginning", "begin");
        c_ori_nor.put("production", "produce");
        c_ori_nor.put("motivation", "motivate");
        c_ori_nor.put("destination", "destine");
        c_ori_nor.put("recording", "record");
        c_ori_nor.put("description", "describe");
        c_ori_nor.put("training", "train");
        c_ori_nor.put("expectation", "expect");
        c_ori_nor.put("assistance", "assist");
        c_ori_nor.put("content", "contain");
        c_ori_nor.put("conclusion", "conclude");
        c_ori_nor.put("examination", "examine");
        c_ori_nor.put("motivate", "motive");
        c_ori_nor.put("statement", "state");
        c_ori_nor.put("definition", "define");
        c_ori_nor.put("emphasize", "emphasis");
        c_ori_nor.put("wreckage", "wreck");
        c_ori_nor.put("notice", "notify");
        c_ori_nor.put("coverage", "cover");
        c_ori_nor.put("evacuation", "evacuate");
        c_ori_nor.put("delivery", "deliver");
        c_ori_nor.put("allocation", "allocate");
        c_ori_nor.put("election", "elect");
        c_ori_nor.put("approval", "approve");
        c_ori_nor.put("suspicion", "suspect");
        c_ori_nor.put("citizenship", "citizen");
        c_ori_nor.put("reading", "read");
        c_ori_nor.put("consumption", "consume");
        c_ori_nor.put("permission", "permit");
        c_ori_nor.put("improvement", "improve");
        c_ori_nor.put("explosion", "explode");
        c_ori_nor.put("landing", "land");
        c_ori_nor.put("management", "manage");
        c_ori_nor.put("guidance", "guide");
        c_ori_nor.put("analyst", "analyze");
        c_ori_nor.put("terrorize", "terror");
        c_ori_nor.put("correspondent", "correspond");
        c_ori_nor.put("handling", "handle");
        c_ori_nor.put("passing", "pass");
        c_ori_nor.put("merger", "merge");
        c_ori_nor.put("pricing", "price");
        c_ori_nor.put("township", "town");
        c_ori_nor.put("parking", "park");
        c_ori_nor.put("tendency", "tend");
        c_ori_nor.put("competition", "compete");
        c_ori_nor.put("tracking", "track");
        c_ori_nor.put("variation", "vary");
        c_ori_nor.put("relation", "relate");
        c_ori_nor.put("preparation", "prepare");
        c_ori_nor.put("belongings", "belong");
        c_ori_nor.put("closing", "close");
        c_ori_nor.put("striking", "strike");
        c_ori_nor.put("implication", "imply");
        c_ori_nor.put("action", "act");
        c_ori_nor.put("reservation", "reserve");
        c_ori_nor.put("connection", "connect");
        c_ori_nor.put("savings", "save");
        c_ori_nor.put("cooperation", "cooperate");
        c_ori_nor.put("inspection", "inspect");
        c_ori_nor.put("generation", "generate");
        c_ori_nor.put("partnership", "partner");
        c_ori_nor.put("advisory", "advise");
        c_ori_nor.put("testing", "test");
        c_ori_nor.put("resistance", "resist");
        c_ori_nor.put("hospitalize", "hospital");
        c_ori_nor.put("analyze", "analyst");
        c_ori_nor.put("integration", "integrate");
        c_ori_nor.put("restriction", "restrict");
        c_ori_nor.put("impression", "impress");
        c_ori_nor.put("indication", "indicate");
        c_ori_nor.put("acting", "act");
        c_ori_nor.put("blessing", "bless");
        c_ori_nor.put("trading", "trade");
        c_ori_nor.put("extension", "extend");
        c_ori_nor.put("intensify", "intensity");
        c_ori_nor.put("signature", "sign");
        c_ori_nor.put("showing", "show");
        c_ori_nor.put("pursuit", "pursue");
        c_ori_nor.put("protection", "protect");
        c_ori_nor.put("condemnation", "condemn");
        c_ori_nor.put("formation", "form");
        c_ori_nor.put("foundation", "found");
        c_ori_nor.put("subscription", "subscribe");
        c_ori_nor.put("distribution", "distribute");
        c_ori_nor.put("notify", "notice");
        c_ori_nor.put("financing", "finance");
        c_ori_nor.put("clearance", "clear");
        c_ori_nor.put("deployment", "deploy");
        c_ori_nor.put("disclosure", "disclose");
        c_ori_nor.put("product", "produce");
        c_ori_nor.put("funding", "fund");
        c_ori_nor.put("gaming", "game");
        c_ori_nor.put("survive", "succumb");
        c_ori_nor.put("agency", "agent");
        c_ori_nor.put("observation", "observe");
        c_ori_nor.put("unify", "unit");
        c_ori_nor.put("suggestion", "suggest");
        c_ori_nor.put("digging", "dig");
        c_ori_nor.put("transformation", "transform");
        c_ori_nor.put("produce", "product");
        c_ori_nor.put("gathering", "gather");
        c_ori_nor.put("earnings", "earn");
        c_ori_nor.put("appearance", "appear");
        c_ori_nor.put("discovery", "discover");
        c_ori_nor.put("firing", "fire");
        c_ori_nor.put("movement", "move");
        c_ori_nor.put("specialize", "specialist");
        c_ori_nor.put("booking", "book");
        c_ori_nor.put("alliance", "ally");
        c_ori_nor.put("condolence", "condole");
        c_ori_nor.put("possession", "possess");
        c_ori_nor.put("recognition", "recognize");
        c_ori_nor.put("rating", "rate");
        c_ori_nor.put("existence", "exist");
        c_ori_nor.put("rebuilding", "rebuild");
        c_ori_nor.put("smuggling", "smuggle");
        c_ori_nor.put("reference", "refer");
        c_ori_nor.put("notification", "notify");
        c_ori_nor.put("ruling", "rule");
        c_ori_nor.put("negotiation", "negotiate");
        c_ori_nor.put("opponent", "oppose");
        c_ori_nor.put("communication", "communicate");
        c_ori_nor.put("residence", "reside");
        c_ori_nor.put("entrance", "enter");
        c_ori_nor.put("closure", "close");
        c_ori_nor.put("combination", "combine");
        c_ori_nor.put("speculation", "speculate");
        c_ori_nor.put("development", "develop");
        c_ori_nor.put("package", "pack");
        c_ori_nor.put("drinking", "drink");
        c_ori_nor.put("comparison", "compare");
        c_ori_nor.put("disruption", "disrupt");
        c_ori_nor.put("survival", "survive");
        c_ori_nor.put("commitment", "commit");
        c_ori_nor.put("equipment", "equip");
        c_ori_nor.put("establishment", "establish");
        c_ori_nor.put("admission", "admit");
        c_ori_nor.put("unveiling", "unveil");
        c_ori_nor.put("excitement", "excite");
        c_ori_nor.put("disappearance", "disappear");
        c_ori_nor.put("expansion", "expand");
        c_ori_nor.put("driving", "drive");
        c_ori_nor.put("collision", "collide");
        c_ori_nor.put("entry", "enter");
        c_ori_nor.put("originate", "origin");
        c_ori_nor.put("capitalization", "capitalize");
        c_ori_nor.put("specialist", "specialize");
        c_ori_nor.put("violation", "violate");
        c_ori_nor.put("prediction", "predict");
        c_ori_nor.put("bombing", "bomb");
        c_ori_nor.put("departure", "depart");
        c_ori_nor.put("correction", "correct");
        c_ori_nor.put("intervention", "intervene");
        c_ori_nor.put("replacement", "replace");
        c_ori_nor.put("option", "opt");
        c_ori_nor.put("limitation", "limit");
        c_ori_nor.put("terrify", "terror");
        c_ori_nor.put("student", "study");
        c_ori_nor.put("arrival", "arrive");
        c_ori_nor.put("recovery", "recover");
        c_ori_nor.put("storage", "store");
        c_ori_nor.put("terrorist", "terror");
        c_ori_nor.put("devastation", "devastate");
        c_ori_nor.put("running", "run");
        c_ori_nor.put("holding", "hold");
        c_ori_nor.put("attendant", "attend");
        c_ori_nor.put("terrorism", "terrorist");
        c_ori_nor.put("leadership", "leader");
        c_ori_nor.put("construction", "construct");
        c_ori_nor.put("magnitude", "magnify");
        c_ori_nor.put("justification", "justify");
        c_ori_nor.put("introduction", "introduce");
        c_ori_nor.put("motion", "move");
        c_ori_nor.put("penetration", "penetrate");
        c_ori_nor.put("assistant", "assist");
        c_ori_nor.put("requirement", "require");
        c_ori_nor.put("opening", "open");
        c_ori_nor.put("rampage", "ramp");
        c_ori_nor.put("prioritize", "priority");
        c_ori_nor.put("intensity", "intensify");
        c_ori_nor.put("performance", "perform");
        c_ori_nor.put("application", "apply");
        c_ori_nor.put("interaction", "interact");
        c_ori_nor.put("reunion", "reunite");
        c_ori_nor.put("investigation", "investigate");
        c_ori_nor.put("attention", "attend");
        c_ori_nor.put("reduction", "reduce");
        c_ori_nor.put("maintenance", "maintain");
        c_ori_nor.put("succumb", "survive");

    }

    public void convertRawFile(int step) throws InterruptedException, ParseException, IOException {
        if (step == 0) {
            //step 0, get other forms for each concept, e.g. acquire, acquisition
            readData(dirPath+"data_total.txt");
            getCIDFormSet();
        } else if (step == 1) {
            //step 1, get labels for each entity
            readData(dirPath+"data_total.txt");
            saveM_F();
        } else if (step == 2) {
            //step 2
            readM_F();
            readData(dirPath + "data_total.txt");
            saveM_M();
        } else if (step == 3) {
            //step 3
            readM_F();
            readM_M();
            readData(dirPath+"data_total.txt");
            buildIndex();
            writeFile();
        }
    }

    /**
     * read sentence information from filePath
     * 1. sentence -- content
     * 2. key-id mapping
     * 3. sentence -- crfid_al, emid_al
     * 4. do not store keywords
     *
     * @param filePath
     * @throws IOException
     * @throws InterruptedException
     */
    HashSet<String> st_invalid = new HashSet<>();

    public void readData(String filePath) throws IOException, InterruptedException, ParseException {
        HashSet<String> crf_invalid = new HashSet<>();
        if(new File(dirPath + "crf_diverse_" + cat + ".txt").exists()){
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "crf_diverse_" + cat + ".txt"), "UTF-8"));
            String s;
            while ((s = in.readLine()) != null) {
                crf_invalid.add(s);
            }
            in.close();
        }
        emid_eid = new int[defCnt];
        emid_mid = new int[defCnt];
        crfid_cid = new int[defCnt];
        crfid_rid = new int[defCnt];
        crfid_fid = new int[defCnt];
        crfid_rfid = new int[defCnt];
        //remove retrospective sentences
        HashSet<String> content_set = new HashSet<>();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
//            System.out.println(s);
            if (!s.equals("*************")) {
                wait();
            }
            String[] sl = in.readLine().split("\t");
            String[] fname_al = sl[0].split("_");
            String st = sl[0] + "_" + sl[2];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            if (cat != -1 && !fname_al[0].equals(String.valueOf(cat))) {
                in.readLine();
                for (int i = 0; i < tpCnt + wCnt; i++)
                    in.readLine();
                continue;
            }
            String e = fname_al[0] + "_" + fname_al[1];
            String content = in.readLine();
            HashMap<String, Integer> crf_cnt = new HashMap<>();
//            System.out.println(st);
            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String c = sl[0].split(":")[0];
                String r = sl[0].split(":")[1];
                String f = sl[1];
                String m = sl[2];
//                if(c.equals("price") && r.equals("quant"))
//                    System.out.println(s);
                if (c_ori_nor.containsKey(c))
                    c = c_ori_nor.get(c);
                if (m_f_ori_nor.containsKey(m))
                    f = m_f_ori_nor.get(m);
                if (m_m_ori_nor.containsKey(m))
                    m = m_m_ori_nor.get(m);
                String rf = r + "::" + f;
                String crf = c + "::" + rf;
                if(crf_invalid.contains(crf))
                    continue;
                Utility.recordCnt(crf, 1, crf_cnt);
            }
            for (int i = 0; i < wCnt; i++)
                in.readLine();
            if (content_set.contains(content)) {
                st_invalid.add(st);
//                System.out.println("1: "+st);
            }
            if (content.length() > 500) {
//                System.out.println("2: "+st);
                st_invalid.add(st);
            }
            for (String crf : crf_cnt.keySet()) {
                if (crf_cnt.get(crf) > 2) {
                    String c = crf.split("::")[0];
                    int cnt = 0;
                    int idx = content.indexOf(c);
                    while (idx != -1) {
                        idx = content.indexOf(c, idx + 1);
                        cnt++;
                    }
                    if (cnt > 1) {
                        st_invalid.add(st);
                        break;
                    }
                }
            }
            content_set.add(content);
        }
        in.close();

        in = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
        while ((s = in.readLine()) != null) {
            if (!s.equals("*************"))
                wait();
            String[] sl = in.readLine().split("\t");
            String[] fname_al = sl[0].split("_");
            String st = sl[0] + "_" + sl[2];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            if (cat != -1 && !fname_al[0].equals(String.valueOf(cat)) || st_invalid.contains(st)) {
                in.readLine();
                for (int i = 0; i < tpCnt + wCnt; i++)
                    in.readLine();
                continue;
            }
            String e = fname_al[0] + "_" + fname_al[1];
            Integer stid = Utility.getID(st, st_stid, stid_st);
            String content = in.readLine();
            stid_content.put(stid, content);
            ArrayList<Integer> crfid_al = new ArrayList<>();
            ArrayList<Integer> emid_al = new ArrayList<>();
            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String c = sl[0].split(":")[0];
                if (c_ori_nor.containsKey(c))
                    c = c_ori_nor.get(c);
                String r = sl[0].split(":")[1];
                String f = sl[1];
                String m = sl[2];
                if (m_f_ori_nor.containsKey(m))
                    f = m_f_ori_nor.get(m);
                if (m_m_ori_nor.containsKey(m))
                    m = m_m_ori_nor.get(m);
                String rf = r + "::" + f;
                String crf = c + "::" + rf;
                if(crf_invalid.contains(crf))
                    continue;
                String em = e + "::" + m;
                int cid = Utility.getID(c, c_cid, cid_c);
                int rid = Utility.getID(r, r_rid, rid_r);
                int fid = Utility.getID(f, f_fid, fid_f);
                int rfid = Utility.getID(rf, rf_rfid, rfid_rf);
                int eid = Utility.getID(e, e_eid, eid_e);
                int mid = Utility.getID(m, m_mid, mid_m);
                int emid = Utility.getID(em, em_emid, emid_em);
                int crfid = Utility.getID(crf, crf_crfid, crfid_crf);
                emid_eid[emid] = eid;
                emid_mid[emid] = mid;
                crfid_cid[crfid] = cid;
                crfid_rid[crfid] = rid;
                crfid_fid[crfid] = fid;
                crfid_rfid[crfid] = rfid;
                boolean duplicate = false;
                for (int k = 0; k < crfid_al.size(); k++) {
                    if (crfid_al.get(k) == crfid && emid_al.get(k) == emid) {
                        duplicate = true;
                    }
                }
                if (!duplicate) {
                    crfid_al.add(crfid);
                    emid_al.add(emid);
                }
            }
            stid_elements.put(stid, new Sent(crfid_al, emid_al));
            for (int i = 0; i < wCnt; i++)
                in.readLine();
        }
        in.close();
        CRF = crf_crfid.size();
        EM = em_emid.size();
        RF = rf_rfid.size();
        D = stid_elements.size();
        C = c_cid.size();
        M = m_mid.size();
        E = e_eid.size();
        R = r_rid.size();
        F = f_fid.size();
        emid_eid = Arrays.copyOf(emid_eid, EM);
        emid_mid = Arrays.copyOf(emid_mid, EM);
        crfid_cid = Arrays.copyOf(crfid_cid, CRF);
        crfid_rid = Arrays.copyOf(crfid_rid, CRF);
        crfid_fid = Arrays.copyOf(crfid_fid, CRF);
        crfid_rfid = Arrays.copyOf(crfid_rfid, CRF);
    }

    protected int getEMEMSim(int emid1, int emid2, int fid) throws InterruptedException, ParseException {
        try {
            SimpleDateFormat sdf_date = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat sdf_time = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            if (emid1 == emid2) return 1;
            String f = fid_f.get(fid);
            String m1 = mid_m.get(emid_mid[emid1]);
            String m2 = mid_m.get(emid_mid[emid2]);
            if (isEntity(m1) == false || isEntity(m2) == false)
                return 0;

            if (f.equals("ORGANIZATION")) {
                if (m1.equals("corp.") || m1.equals("inc.") || m2.equals("corp.") || m1.equals("inc."))
                    return 0;
                if (m1.contains(" ")) {
                    String abbr1 = "";
                    for (String comp : m1.split(" "))
                        abbr1 += comp.substring(0, 1);
                    if (m2.equals(abbr1))
                        return 1;
                }
                if (m2.contains(" ")) {
                    String abbr2 = "";
                    for (String comp : m2.split(" "))
                        abbr2 += comp.substring(0, 1);
                    if (m1.equals(abbr2))
                        return 1;
                }
                if (m1.contains(m2)) {
                    String m1_rem = m1.replace(m2, "");
                    m1_rem = m1_rem.replace("inc", "").replace("co.", "").replace("company", "").replace("corp", "").replace("corporation", "").replace("international", "").replace(".", "").replace(" ", "");
                    if (m1_rem.length() < 2) {
                        return 1;
                    }
                }
                if (m2.contains(m1)) {
                    String m2_rem = m2.replace(m1, "");
                    m2_rem = m2_rem.replace("inc", "").replace("co.", "").replace("company", "").replace("corp", "").replace("corporation", "").replace("international", "").replace(".", "").replace(" ", "");
                    if (m2_rem.length() < 2) {
                        return 1;
                    }
                }
            }
            if (f.equals("PERSON") || f.equals("LOCATION")) {
                if (m1.contains(m2) || m2.contains(m1))
                    return 1;
            }
            if (f.equals("DATE")) {
                Date date1 = sdf_date.parse(m1);
                Date date2 = sdf_date.parse(m2);
                int hour_diff = Math.abs((int) ((date2.getTime() - date1.getTime()) / 1000 / 60 / 60));
                if (hour_diff <= 24)
                    return 1;
            } else if (f.equals("TIME")) {
                Date date1 = sdf_time.parse(m1);
                Date date2 = sdf_time.parse(m2);
                int hour_diff = Math.abs((int) ((date2.getTime() - date1.getTime()) / 1000 / 60 / 60));
                if (hour_diff <= 8)
                    return 1;
            } else if (f.equals("MONEY")) {
                if (!m1.contains("$") || !m2.contains("$"))
                    return 0;
                while (!m1.substring(0, 1).equals("$"))
                    m1 = m1.substring(1);
                m1 = m1.substring(1);
                while (!m2.substring(0, 1).equals("$"))
                    m2 = m2.substring(1);
                m2 = m2.substring(1);
                if (m1.contains("e") && m2.contains("e")) {
                    if (!m1.split("e")[1].equals(m2.split("e")[1]))
                        return 0;
                    m1 = m1.split("e")[0];
                    m2 = m2.split("e")[0];
                }
                if (m1.contains("e") && !m2.contains("e") || !m1.contains("e") && m2.contains("e"))
                    return 0;
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.05)
                    return 1;
            } else if (f.equals("PERCENT")) {
                while (!m1.substring(0, 1).equals("%"))
                    m1 = m1.substring(1);
                m1 = m1.substring(1);
                while (!m2.substring(0, 1).equals("%"))
                    m2 = m2.substring(1);
                m2 = m2.substring(1);
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.05)
                    return 1;
            } else if (f.equals("NUMBER")) {
                while (!m1.substring(0, 1).matches("[0-9]")) {
                    m1 = m1.substring(1);
                }
                while (!m2.substring(0, 1).matches("[0-9]")) {
                    m2 = m2.substring(1);
                }
                Double v1 = Double.valueOf(m1);
                Double v2 = Double.valueOf(m2);
//            System.out.println(v1+"\t"+v2+"\t"+Math.abs(v2 - v1) / Math.max(v1, v2));
                if (Math.abs(v2 - v1) / Math.max(v1, v2) <= 0.05)
                    return 1;
            }
        } catch (Exception e) {
            return 0;
        }
        return 0;
    }

    public void ststCov_simple(int stid1, int stid2) throws ParseException, InterruptedException {
        Sent elem1 = stid_elements.get(stid1);
        Sent elem2 = stid_elements.get(stid2);
        ArrayList<Integer> crfid_al1 = new ArrayList<>();
        ArrayList<Integer> crfid_al2 = new ArrayList<>();
        ArrayList<Integer> emid_al1 = new ArrayList<>();
        ArrayList<Integer> emid_al2 = new ArrayList<>();

        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_2 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_2 = new HashMap<>();
        for (int i = 0; i < elem1.size; i++) {
            int crfid = elem1.crfid_al.get(i);
            int emid = elem1.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_1.containsKey(cid))
                cid_crfid_emid_set_1.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_1.get(cid).containsKey(crfid))
                cid_crfid_emid_set_1.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_1.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_1.containsKey(cid))
                cid_rid_fid_set_1.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_1.get(cid).containsKey(rid))
                cid_rid_fid_set_1.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_1.get(cid).get(rid).add(crfid);
        }
        for (int i = 0; i < elem2.size; i++) {
            int crfid = elem2.crfid_al.get(i);
            int emid = elem2.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            int fid = crfid_fid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_2.containsKey(cid))
                cid_crfid_emid_set_2.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_2.get(cid).containsKey(crfid))
                cid_crfid_emid_set_2.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_2.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_2.containsKey(cid))
                cid_rid_fid_set_2.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_2.get(cid).containsKey(rid))
                cid_rid_fid_set_2.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_2.get(cid).get(rid).add(crfid);
        }

        for (int cid : cid_rid_fid_set_1.keySet()) {
            for (int rid : cid_rid_fid_set_1.get(cid).keySet()) {
                if (cid_rid_fid_set_1.get(cid).get(rid).size() > 1) {
                    for (Integer crfid : cid_rid_fid_set_1.get(cid).get(rid))
                        cid_crfid_emid_set_1.get(cid).remove(crfid);
                }
            }
        }
        for (int cid : cid_rid_fid_set_2.keySet()) {
            for (int rid : cid_rid_fid_set_2.get(cid).keySet()) {
                if (cid_rid_fid_set_2.get(cid).get(rid).size() > 1) {
                    for (Integer crfid : cid_rid_fid_set_2.get(cid).get(rid))
                        cid_crfid_emid_set_2.get(cid).remove(crfid);
                }
            }
        }
        for (int i = 0; i < elem1.size; i++) {
            int crfid1 = elem1.crfid_al.get(i), cid1 = crfid_cid[crfid1], rid1 = crfid_rid[crfid1];
            for (int j = 0; j < elem2.size; j++) {
                int crfid2 = elem2.crfid_al.get(j), cid2 = crfid_cid[crfid2], rid2 = crfid_rid[crfid2];
                if (rid_r.get(rid2).contains("ARG") && !cid_crfid_emid_set_2.get(cid2).containsKey(crfid2)) continue;
                if (crfid_fid[crfid1] != crfid_fid[crfid2]) continue;
                if (getEMEMSim(elem1.emid_al.get(i), elem2.emid_al.get(j), crfid_fid[crfid1]) == 1) {
                    crfid_al1.add(elem1.crfid_al.get(i));
                    crfid_al2.add(elem2.crfid_al.get(j));
                    emid_al1.add(elem1.emid_al.get(i));
                    emid_al2.add(elem2.emid_al.get(j));
                }
            }
        }
        int size_1 = new HashSet<>(crfid_al1).size(), size_2 = new HashSet<>(crfid_al2).size();
        int w = Math.min(size_1, size_2);
        if (w == 0)
            return;
        lid_crfid_map[lid] = new int[crfid_al1.size()][2];
        for (int i = 0; i < lid_crfid_map[lid].length; i++) {
            lid_crfid_map[lid][i][0] = crfid_al1.get(i);
            lid_crfid_map[lid][i][1] = crfid_al2.get(i);
            lid_emid_map[lid][0] = emid_al1.get(i);
            lid_emid_map[lid][1] = emid_al2.get(i);
        }
        lid_weight[lid] = w;
        lid_stidstid[lid] = stid1 + ":" + stid2;
        lid++;
    }

    public void ststCov_new(int stid1, int stid2) throws ParseException, InterruptedException {
        Sent elem1 = stid_elements.get(stid1);
        Sent elem2 = stid_elements.get(stid2);
        ArrayList<Integer> crfid_al1 = new ArrayList<>();
        ArrayList<Integer> crfid_al2 = new ArrayList<>();
        ArrayList<Integer> emid_al1 = new ArrayList<>();
        ArrayList<Integer> emid_al2 = new ArrayList<>();
        //construct cid_rid_fid set for predicates in both sentences
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_2 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_2 = new HashMap<>();
        for (int i = 0; i < elem1.size; i++) {
            int crfid = elem1.crfid_al.get(i);
            int emid = elem1.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_1.containsKey(cid))
                cid_crfid_emid_set_1.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_1.get(cid).containsKey(crfid))
                cid_crfid_emid_set_1.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_1.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_1.containsKey(cid))
                cid_rid_fid_set_1.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_1.get(cid).containsKey(rid))
                cid_rid_fid_set_1.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_1.get(cid).get(rid).add(crfid);
        }
        for (int i = 0; i < elem2.size; i++) {
            int crfid = elem2.crfid_al.get(i);
            int emid = elem2.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            int fid = crfid_fid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_2.containsKey(cid))
                cid_crfid_emid_set_2.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_2.get(cid).containsKey(crfid))
                cid_crfid_emid_set_2.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_2.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_2.containsKey(cid))
                cid_rid_fid_set_2.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_2.get(cid).containsKey(rid))
                cid_rid_fid_set_2.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_2.get(cid).get(rid).add(crfid);
        }

        for (int i = 0; i < elem1.size; i++) {
            int crfid1 = elem1.crfid_al.get(i), cid1 = crfid_cid[crfid1], rid1 = crfid_rid[crfid1];
            if (rid_r.get(rid1).contains("ARG") && !cid_crfid_emid_set_1.get(cid1).containsKey(crfid1)) continue;
            for (int j = 0; j < elem2.size; j++) {
                int crfid2 = elem2.crfid_al.get(j), cid2 = crfid_cid[crfid2], rid2 = crfid_rid[crfid2];
                if (crfid_fid[crfid1] != crfid_fid[crfid2]) continue;

                if (getEMEMSim(elem1.emid_al.get(i), elem2.emid_al.get(j), crfid_fid[crfid1]) == 1) {
                    if (rid_r.get(rid1).contains("ARG") && rid_r.get(rid2).contains("ARG")) {
                        boolean flag = false;

                        //if both crf are arguments, their predicates must have other arguments in the two sentences
                        for (int crfid1_tmp : cid_crfid_emid_set_1.get(cid1).keySet()) {
                            for (int crfid2_tmp : cid_crfid_emid_set_2.get(cid2).keySet()) {
                                int rid1_tmp = crfid_rid[crfid1_tmp], rid2_tmp = crfid_rid[crfid2_tmp];
                                if (rid1 == rid1_tmp || rid2 == rid2_tmp)
                                    continue;      //if current arguements are the same with the target ones
                                boolean isCommon = false;       //if crfid1_tmp and crfid2_tmp has common value
                                for (int emid1 : cid_crfid_emid_set_1.get(cid1).get(crfid1_tmp))
                                    for (int emid2 : cid_crfid_emid_set_2.get(cid2).get(crfid2_tmp))
                                        if (getEMEMSim(emid1, emid2, crfid_fid[crfid1_tmp]) == 1)
                                            isCommon = true;
                                if (isCommon) {
                                    flag = true;
                                }
                            }
                        }
//                        }
                        if (flag == true) {
                            crfid_al1.add(elem1.crfid_al.get(i));
                            crfid_al2.add(elem2.crfid_al.get(j));
                            emid_al1.add(elem1.emid_al.get(i));
                            emid_al2.add(elem2.emid_al.get(j));
                        }
                    } else {
                        crfid_al1.add(elem1.crfid_al.get(i));
                        crfid_al2.add(elem2.crfid_al.get(j));
                        emid_al1.add(elem1.emid_al.get(i));
                        emid_al2.add(elem2.emid_al.get(j));
                    }
                }
            }
        }
        int size_1 = new HashSet<>(crfid_al1).size(), size_2 = new HashSet<>(crfid_al2).size();
        int w = Math.min(size_1, size_2);
        if (w == 0)
            return;
        lid_crfid_map[lid] = new int[crfid_al1.size()][2];
        for (int i = 0; i < lid_crfid_map[lid].length; i++) {
            lid_crfid_map[lid][i][0] = crfid_al1.get(i);
            lid_crfid_map[lid][i][1] = crfid_al2.get(i);
            lid_emid_map[lid][0] = emid_al1.get(i);
            lid_emid_map[lid][1] = emid_al2.get(i);
        }
        lid_weight[lid] = w;
        lid_stidstid[lid] = stid1 + ":" + stid2;
        lid++;
    }

    public void ststCov(int stid1, int stid2) throws ParseException, InterruptedException {
        Sent elem1 = stid_elements.get(stid1);
        Sent elem2 = stid_elements.get(stid2);
        ArrayList<Integer> crfid_al1 = new ArrayList<>();
        ArrayList<Integer> crfid_al2 = new ArrayList<>();
        ArrayList<Integer> emid_al1 = new ArrayList<>();
        ArrayList<Integer> emid_al2 = new ArrayList<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_1 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_crfid_emid_set_2 = new HashMap<>();
        HashMap<Integer, HashMap<Integer, HashSet<Integer>>> cid_rid_fid_set_2 = new HashMap<>();
        for (int i = 0; i < elem1.size; i++) {
            int crfid = elem1.crfid_al.get(i);
            int emid = elem1.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            int fid = crfid_fid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_1.containsKey(cid))
                cid_crfid_emid_set_1.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_1.get(cid).containsKey(crfid))
                cid_crfid_emid_set_1.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_1.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_1.containsKey(cid))
                cid_rid_fid_set_1.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_1.get(cid).containsKey(rid))
                cid_rid_fid_set_1.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_1.get(cid).get(rid).add(crfid);
        }
        for (int i = 0; i < elem2.size; i++) {
            int crfid = elem2.crfid_al.get(i);
            int emid = elem2.emid_al.get(i);
            int cid = crfid_cid[crfid];
            int rid = crfid_rid[crfid];
            int fid = crfid_fid[crfid];
            if (!rid_r.get(rid).contains("ARG"))
                continue;
            if (!cid_crfid_emid_set_2.containsKey(cid))
                cid_crfid_emid_set_2.put(cid, new HashMap<>());
            if (!cid_crfid_emid_set_2.get(cid).containsKey(crfid))
                cid_crfid_emid_set_2.get(cid).put(crfid, new HashSet<>());
            cid_crfid_emid_set_2.get(cid).get(crfid).add(emid);
            if (!cid_rid_fid_set_2.containsKey(cid))
                cid_rid_fid_set_2.put(cid, new HashMap<>());
            if (!cid_rid_fid_set_2.get(cid).containsKey(rid))
                cid_rid_fid_set_2.get(cid).put(rid, new HashSet<>());
            cid_rid_fid_set_2.get(cid).get(rid).add(crfid);
        }
        for (int cid : cid_rid_fid_set_1.keySet()) {
            for (int rid : cid_rid_fid_set_1.get(cid).keySet()) {
                if (cid_rid_fid_set_1.get(cid).get(rid).size() > 1) {
                    for (Integer crfid : cid_rid_fid_set_1.get(cid).get(rid))
                        cid_crfid_emid_set_1.get(cid).remove(crfid);
                }
            }
        }
        for (int cid : cid_rid_fid_set_2.keySet()) {
            for (int rid : cid_rid_fid_set_2.get(cid).keySet()) {
                if (cid_rid_fid_set_2.get(cid).get(rid).size() > 1) {
                    for (Integer crfid : cid_rid_fid_set_2.get(cid).get(rid))
                        cid_crfid_emid_set_2.get(cid).remove(crfid);
                }
            }
        }

        for (int i = 0; i < elem1.size; i++) {
            int crfid1 = elem1.crfid_al.get(i), cid1 = crfid_cid[crfid1], rid1 = crfid_rid[crfid1];
            if (rid_r.get(rid1).contains("ARG") && !cid_crfid_emid_set_1.get(cid1).containsKey(crfid1)) continue;
            for (int j = 0; j < elem2.size; j++) {
                int crfid2 = elem2.crfid_al.get(j), cid2 = crfid_cid[crfid2], rid2 = crfid_rid[crfid2];
                if (rid_r.get(rid2).contains("ARG") && !cid_crfid_emid_set_2.get(cid2).containsKey(crfid2)) continue;
                if (crfid_fid[crfid1] != crfid_fid[crfid2]) continue;
                if (getEMEMSim(elem1.emid_al.get(i), elem2.emid_al.get(j), crfid_fid[crfid1]) == 1) {
                    if (rid_r.get(rid1).contains("ARG") && rid_r.get(rid2).contains("ARG")) {
                        boolean flag = false;
                        for (int crfid1_tmp : cid_crfid_emid_set_1.get(cid1).keySet()) {
                            for (int crfid2_tmp : cid_crfid_emid_set_2.get(cid2).keySet()) {
                                int rid1_tmp = crfid_rid[crfid1_tmp], rid2_tmp = crfid_rid[crfid2_tmp];
                                if (crfid1 == crfid1_tmp || crfid2 == crfid2_tmp) continue;
                                if (rid1 == rid1_tmp || rid2 == rid2_tmp) continue;
                                if (rid1 == rid2 && rid1_tmp != rid2_tmp || rid1 != rid2 && rid1_tmp == rid2_tmp)
                                    continue;
                                if (rid1 == rid2_tmp && rid2 != rid1_tmp || rid2 == rid1_tmp && rid1 != rid2_tmp)
                                    continue;
                                if (cid1 == cid2) continue;
                                boolean isCommon = false;
                                for (int emid1 : cid_crfid_emid_set_1.get(cid1).get(crfid1_tmp))
                                    for (int emid2 : cid_crfid_emid_set_2.get(cid2).get(crfid2_tmp))
                                        if (getEMEMSim(emid1, emid2, crfid_fid[crfid1_tmp]) == 1)
                                            isCommon = true;
                                if (isCommon) {
                                    flag = true;
                                    if (stid_st.get(stid1).equals("0_0_975_9") && stid_st.get(stid2).equals("0_0_140_4")) {
                                        System.out.println("ori: " + crfid_crf.get(crfid1) + "\t\t" + crfid_crf.get(crfid2));
                                        for (int emid : cid_crfid_emid_set_1.get(cid1).get(crfid1))
                                            System.out.println("value 1: " + emid_em.get(emid));
                                        for (int emid : cid_crfid_emid_set_2.get(cid2).get(crfid2))
                                            System.out.println("value 2: " + emid_em.get(emid));
                                        System.out.println("tmp: " + crfid_crf.get(crfid1_tmp) + "\t\t" + crfid_crf.get(crfid2_tmp));
                                        for (int emid : cid_crfid_emid_set_1.get(cid1).get(crfid1_tmp))
                                            System.out.println("value 1: " + emid_em.get(emid));
                                        for (int emid : cid_crfid_emid_set_2.get(cid2).get(crfid2_tmp))
                                            System.out.println("value 2: " + emid_em.get(emid));
                                    }
                                }
                            }
                        }
                        if (flag == true) {
                            crfid_al1.add(elem1.crfid_al.get(i));
                            crfid_al2.add(elem2.crfid_al.get(j));
                            emid_al1.add(elem1.emid_al.get(i));
                            emid_al2.add(elem2.emid_al.get(j));
                        }
                    } else {
                        crfid_al1.add(elem1.crfid_al.get(i));
                        crfid_al2.add(elem2.crfid_al.get(j));
                        emid_al1.add(elem1.emid_al.get(i));
                        emid_al2.add(elem2.emid_al.get(j));
                    }
                }
            }
        }
        int size_1 = new HashSet<>(crfid_al1).size(), size_2 = new HashSet<>(crfid_al2).size();
        int w = Math.min(size_1, size_2);
        if (w == 0)
            return;
        lid_crfid_map[lid] = new int[crfid_al1.size()][2];
        for (int i = 0; i < lid_crfid_map[lid].length; i++) {
            lid_crfid_map[lid][i][0] = crfid_al1.get(i);
            lid_crfid_map[lid][i][1] = crfid_al2.get(i);
            lid_emid_map[lid][0] = emid_al1.get(i);
            lid_emid_map[lid][1] = emid_al2.get(i);
        }
        lid_weight[lid] = w;
        lid_stidstid[lid] = stid1 + ":" + stid2;
        lid++;
    }

    protected void buildIndex() throws ParseException, InterruptedException {
        //build reverse index emid -- stid set
        lid_crfid_map = new int[defCnt][][];
        lid_emid_map = new int[defCnt][2];
        lid_weight = new double[defCnt];
        lid_stidstid = new String[defCnt];
        HashMap<IDPair, HashSet<Integer>> emidfid_stid_set = new HashMap<>();
        for (Map.Entry<Integer, Sent> entry : stid_elements.entrySet()) {
            int stid = entry.getKey();
            Sent elem = entry.getValue();
            for (int i = 0; i < elem.size; i++) {
                int emid = elem.emid_al.get(i);
                int fid = crfid_fid[elem.crfid_al.get(i)];
                IDPair p = new IDPair(emid, fid);
                if (!emidfid_stid_set.containsKey(p))
                    emidfid_stid_set.put(p, new HashSet<>());
                emidfid_stid_set.get(p).add(stid);
            }
        }
        HashMap<IDPair, HashSet<IDPair>> emidfid_emidfid_same = new HashMap<>();
        ArrayList<IDPair> emidfid_al = new ArrayList<>(emidfid_stid_set.keySet());
        for (int i = 0; i < emidfid_al.size(); i++) {
            IDPair p1 = emidfid_al.get(i);
            for (int j = 0; j < emidfid_al.size(); j++) {
                IDPair p2 = emidfid_al.get(j);
                if (p1.id2 != p2.id2) continue;
                if (getEMEMSim(p1.id1, p2.id1, p1.id2) != 0) {
                    if (!emidfid_emidfid_same.containsKey(p1))
                        emidfid_emidfid_same.put(p1, new HashSet<>());
                    if (!emidfid_emidfid_same.containsKey(p2))
                        emidfid_emidfid_same.put(p2, new HashSet<>());
                    emidfid_emidfid_same.get(p1).add(p2);
                    emidfid_emidfid_same.get(p2).add(p1);
                }
            }
        }
//        System.out.println("end1\n\n");
        for (int stid1 = 0; stid1 < D; stid1++) {
//            System.out.println(stid1+"/"+D);
            HashSet<Integer> stid_cand_set = new HashSet<>();
            for (int i = 0; i < stid_elements.get(stid1).size; i++) {
                IDPair p = new IDPair(stid_elements.get(stid1).emid_al.get(i), crfid_fid[stid_elements.get(stid1).crfid_al.get(i)]);
                for (IDPair p1 : emidfid_emidfid_same.get(p)) {
                    stid_cand_set.addAll(emidfid_stid_set.get(p1));
                }
            }
            for (int stid2 : stid_cand_set) {
                ststCov(stid1, stid2);
            }
        }
//        System.out.println("end2");
        L = lid;
        lid_crfid_map = Arrays.copyOf(lid_crfid_map, L);
        lid_emid_map = Arrays.copyOf(lid_emid_map, L);
        lid_weight = Arrays.copyOf(lid_weight, L);
        lid_stidstid = Arrays.copyOf(lid_stidstid, L);
    }


    private void writeFile() throws IOException, InterruptedException {
        HashSet<Integer> stid_set_valid = new HashSet<>();
        HashSet<Integer> lid_set_valid = new HashSet<>();
        for (int lid = 0; lid < lid_stidstid.length; lid++) {
            Integer stid_1 = Integer.valueOf(lid_stidstid[lid].split(":")[0]);
            Integer stid_2 = Integer.valueOf(lid_stidstid[lid].split(":")[1]);
            boolean isValid = false;
            for (int i = 0; i < lid_crfid_map[lid].length; i++) {
                int crfid1 = lid_crfid_map[lid][i][0];
                int crfid2 = lid_crfid_map[lid][i][1];
                if (!crfid_crf.get(crfid1).contains("null") && !crfid_crf.get(crfid2).contains("null")) {
                    isValid = true;
                }
            }
            if (isValid) {
                stid_set_valid.add(stid_1);
                stid_set_valid.add(stid_2);
                lid_set_valid.add(lid);
            }
        }
        HashSet<String> crf_invalid = new HashSet<>();
        if(new File(dirPath + "crf_diverse_" + cat + ".txt").exists()){
            BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "crf_diverse_" + cat + ".txt"), "UTF-8"));
            String s;
            while ((s = in.readLine()) != null) {
                crf_invalid.add(s);
            }
            in.close();
        }
        //read keyword and time of sent from original file
        HashMap<Integer, ArrayList<String>> stid_keyword_al = new HashMap<>();
        HashMap<Integer, String> stid_time = new HashMap<>();
        HashMap<Integer, Integer> eid_stid_valid_cnt = new HashMap<>();
        HashMap<Integer, Integer> stid_eid = new HashMap<>();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data_total.txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            if (!s.equals("*************"))
                wait();
            String[] sl = in.readLine().split("\t");
            String[] fname_al = sl[0].split("_");
            String st = sl[0] + "_" + sl[2];
            String time = sl[3];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            if (!fname_al[0].equals(String.valueOf(cat)) || st_invalid.contains(st)) {
                in.readLine();
                for (int i = 0; i < tpCnt + wCnt; i++)
                    in.readLine();
                continue;
            }
            String e = fname_al[0] + "_" + fname_al[1];
            int eid = Utility.getID(e, e_eid, eid_e);

            Integer stid = Utility.getID(st, st_stid, stid_st);
            in.readLine();
            ArrayList<String> keyword_al = new ArrayList<>();
            for (int i = 0; i < tpCnt; i++)
                in.readLine();
            for (int i = 0; i < wCnt; i++)
                keyword_al.add(in.readLine());
            if (stid_set_valid.contains(stid)) {
                stid_keyword_al.put(stid, keyword_al);
                stid_time.put(stid, time);
                Utility.recordCnt(eid, 1, eid_stid_valid_cnt);
                stid_eid.put(stid, eid);
            }
        }
        in.close();

        HashSet<Integer> lid_set_invalid_tmp = new HashSet<>();
        HashSet<Integer> stid_set_invalid_tmp = new HashSet<>();
        for (int lid : lid_set_valid) {
            Integer stid_1 = Integer.valueOf(lid_stidstid[lid].split(":")[0]);
            Integer stid_2 = Integer.valueOf(lid_stidstid[lid].split(":")[1]);
            if (eid_stid_valid_cnt.get(stid_eid.get(stid_1)) < 50) {
                stid_set_invalid_tmp.add(stid_1);
                stid_set_invalid_tmp.add(stid_2);
                lid_set_invalid_tmp.add(lid);
            }
        }
        for (int lid : lid_set_invalid_tmp)
            lid_set_valid.remove(lid);
        for (int stid : stid_set_invalid_tmp)
            stid_set_valid.remove(stid);

        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "data_cat_new_" + cat + ".txt"), "UTF-8"));
        for (int stid = 0; stid < D; stid++) {
            ArrayList<Integer> crfid_al = new ArrayList<>();
            ArrayList<Integer> emid_al = new ArrayList<>();
            Sent elem = stid_elements.get(stid);
            for (int i = 0; i < elem.size; i++) {
                crfid_al.add(elem.crfid_al.get(i));
                emid_al.add(elem.emid_al.get(i));
            }
            if (!stid_set_valid.contains(stid)) continue;
            if (crfid_al.size() > 0) {
                out.println("*************");
                String st = stid_st.get(stid);
                String fName = st.substring(0, st.lastIndexOf("_"));
                String stNum = st.substring(st.lastIndexOf("_") + 1, st.length());
                out.println(fName + "\t" + fName + "\t" + stNum + "\t" + stid_time.get(stid) + "\t" + crfid_al.size() + "\t" + stid_keyword_al.get(stid).size());
                out.println(stid_content.get(stid));
                for (int i = 0; i < crfid_al.size(); i++) {
                    String[] crf_al = crfid_crf.get(crfid_al.get(i)).split("::");
                    out.println(crf_al[0] + ":" + crf_al[1] + "\t" + crf_al[2] + "\t" + emid_em.get(emid_al.get(i)).split("::")[1]);
                }
                for (String keyword : stid_keyword_al.get(stid))
                    out.println(keyword);
                stid_set_valid.add(stid);
            }
        }
        out.close();

        out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "stst_cnt_crf_" + cat + ".txt"), "UTF-8"));
        for (int lid = 0; lid < lid_stidstid.length; lid++) {
            Integer stid1 = Integer.valueOf(lid_stidstid[lid].split(":")[0]);
            Integer stid2 = Integer.valueOf(lid_stidstid[lid].split(":")[1]);
            if (stid_set_valid.contains(stid1) && stid_set_valid.contains(stid2) && lid_set_valid.contains(lid)) {
                out.print(stid_st.get(stid1) + "\t" + stid_st.get(stid2) + "\t" + Double.valueOf(lid_weight[lid]).intValue());
                for (int i = 0; i < lid_crfid_map[lid].length; i++) {
                    int crfid1 = lid_crfid_map[lid][i][0];
                    int crfid2 = lid_crfid_map[lid][i][1];
                    int emid1 = lid_emid_map[lid][0];
                    int emid2 = lid_emid_map[lid][1];
                    if (crfid1 != crfid2)
                        out.print("\t" + crfid_crf.get(crfid1) + ":::" + crfid_crf.get(crfid2) + ":::" + emid_em.get(emid1) + ":::" + emid_em.get(emid2));
                }
                out.println();
            }
        }
        out.close();
        out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "st_content_" + cat + ".txt"), "UTF-8"));
        for (int stid = 0; stid < stid_content.size(); stid++) {
            if (stid_set_valid.contains(stid))
                out.println(stid_st.get(stid) + "\t" + stid_content.get(stid));
        }
        out.close();
    }

    private boolean isEntity(String word_str) {
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(word_str, POS.VERB), dict.getIndexWord(word_str, POS.NOUN)};
        for (IIndexWord idxWord : idxWord_al) {       //for each POS
            if (idxWord != null)
                return false;
        }
        return true;
    }

    private HashSet<String> getOtherForm(String word_str, IDictionary dict) {
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(word_str, POS.VERB), dict.getIndexWord(word_str, POS.NOUN)};
        HashSet<String> form_set = new HashSet<>();
        for (IIndexWord idxWord : idxWord_al) {       //for each POS
            if (idxWord == null)
                continue;
            for (IWordID wordID : idxWord.getWordIDs()) {     //for each current word
                IWord word = dict.getWord(wordID);
                for (IWordID wordID_rel : word.getRelatedWords()) {       //for each related word of current word
                    IWord word_rel = dict.getWord(wordID_rel);
                    if (word_rel.getLemma().contains("_") || word_rel.getLemma().length() < 2 || word.getLemma().length() < 2 || !word_rel.getLemma().substring(0, 2).equals(word.getLemma().substring(0, 2)))
                        continue;
                    if (!(word_rel.getPOS() == POS.VERB || word_rel.getPOS() == POS.NOUN)) continue;
                    form_set.add(word_rel.getLemma());       //add it as synonyms
                }
            }
        }
        return form_set;
    }

    public void getCIDFormSet() throws IOException {
        HashSet<String> s_set = new HashSet<>();
        for (int cid1 = 0; cid1 < C; cid1++) {
            HashSet<Integer> cid_form_set = new HashSet<>();
            for (String c2 : getOtherForm(cid_c.get(cid1), dict)) {
                Integer cid2 = c_cid.get(c2);
                if (cid2 == null || cid2.equals(cid1)) continue;
                cid_form_set.add(cid2);
            }
            if (cid_form_set.size() > 0) {
                String c1 = cid_c.get(cid1);
                for (int cid2 : cid_form_set) {
                    String c2 = cid_c.get(cid2);
                    String c1_tmp, c2_tmp;
                    if (c1.length() > c2.length()) {
                        c1_tmp = c1;
                        c2_tmp = c2;
                    } else {
                        c1_tmp = c2;
                        c2_tmp = c1;
                    }
                    if (c1_tmp.contains("er") && c1_tmp.lastIndexOf("er") == c1_tmp.length() - 2 || c1_tmp.contains("or") && c1_tmp.lastIndexOf("or") == c1_tmp.length() - 2)
                        continue;
                    s_set.add("c_ori_nor.put(\"" + c1_tmp + "\", \"" + c2_tmp + "\");");
                }
            }
        }
        for (String s : s_set)
            System.out.println(s);
    }

    public void readM_F() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "m_f_" + cat + "_done.txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = s.split("\t");
            m_f_ori_nor.put(sl[0], sl[1]);
        }
        in.close();
    }

    HashMap<String, String> m_name_ori_nor = new HashMap<>();

    public void readM_M() throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "m_ori_target_" + cat + ".txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = s.split("\t");
            m_m_ori_nor.put(sl[0], sl[1]);
        }
        in.close();
    }
    private int getID(int[] root, int id) {
        while (id != root[id]) {
            root[id] = root[root[id]];
            id = root[id];
        }
        return id;
    }
    public void saveM_M() throws ParseException, InterruptedException, FileNotFoundException, UnsupportedEncodingException {
//        int[][] W = new int[M][M];
        HashMap<Integer, HashSet<Integer>> fid_emid = new HashMap<>();
        for (int stid : stid_elements.keySet()) {
            Sent elem = stid_elements.get(stid);
            for (int i = 0; i < elem.size; i++) {
                int fid = crfid_fid[elem.crfid_al.get(i)];
                int emid = elem.emid_al.get(i);
                if (!fid_emid.containsKey(fid))
                    fid_emid.put(fid, new HashSet<>());
                fid_emid.get(fid).add(emid);
            }
        }
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "m_ori_target_" + cat + ".txt"), "UTF-8"));
        for (int fid : fid_emid.keySet()) {     //for each entity label
            String f = fid_f.get(fid);
            int[] root = new int[EM];
            for (int emid = 0; emid < EM; emid++) {
                root[emid] = emid;
            }
            HashMap<String, String> m_name_ori_nor_tmp = new HashMap<>();
            ArrayList<Integer> emid_al = new ArrayList<>(fid_emid.get(fid));
            for (int i = 0; i < emid_al.size(); i++) {
                int emid1 = emid_al.get(i);
                int mid1 = emid_mid[emid1];
                int eid1 = emid_eid[emid1];
                String m1 = mid_m.get(mid1);    //first mention name
                for (int j = i + 1; j < emid_al.size(); j++) {
                    int emid2 = emid_al.get(j);
                    int eid2 = emid_eid[emid2];
                    int mid2 = emid_mid[emid2];
                    String m2 = mid_m.get(mid2);    //second mention name
                    if (eid1 == eid2 && getEMEMSim(emid1, emid2, fid) == 1) {
                        int id1 = getID(root, emid1);
                        int id2 = getID(root, emid2);
                        if (id1 != id2) {
                            root[id1] = root[id2];
                        }
                    }
                }

            }
            HashMap<Integer, HashSet<Integer>> id_emidSet = new HashMap<>();
            for (int emid : emid_al) {
                int id = getID(root, emid);
                if (!id_emidSet.containsKey(id)) {
                    id_emidSet.put(id, new HashSet<>());
                }
                id_emidSet.get(id).add(emid);
            }
            for (int id : id_emidSet.keySet()) {
                if (f.equals("PERSON") || f.equals("ORGANIZATION") || f.equals("LOCATION")) {
                    String key = "";
                    int emid_key = 0;
                    int len = Integer.MAX_VALUE;
                    for (int emid : id_emidSet.get(id)) {
                        String m = mid_m.get(emid_mid[emid]);
                        if (m.length() < len) {
                            len = m.length();
                            key = m;
                            emid_key = emid;
                        }
                    }
                    for (int emid : id_emidSet.get(id)) {
                        if (emid != emid_key) {
                            out.println(mid_m.get(emid_mid[emid]) + "\t" + key);
                            System.out.println(mid_m.get(emid_mid[emid]) + "\t" + key);
                        }
                    }
                } else {
                    ArrayList<Integer> emidAl = new ArrayList<>(id_emidSet.get(id));
                    while (emidAl.size() > 0) {
                        int emid_key = emidAl.get(0);
                        ArrayList<Integer> deleteAl = new ArrayList<>();
                        deleteAl.add(0);
                        for (int i = 1; i < emidAl.size(); i++) {
                            int emid = emidAl.get(i);
                            if (emid_eid[emid_key] == emid_eid[emid] && getEMEMSim(emid, emid_key, fid) == 1) {
                                deleteAl.add(i);
                                out.println(mid_m.get(emid_mid[emid]) + "\t" + mid_m.get(emid_mid[emid_key]));
                                System.out.println(mid_m.get(emid_mid[emid]) + "\t" + mid_m.get(emid_mid[emid_key]));
                            }
                        }
                        for (int i = deleteAl.size() - 1; i >= 0; i--) {
                            emidAl.remove(i);
                        }
                    }
                }
            }
        }
        out.close();
    }

    public void saveM_F() throws FileNotFoundException, UnsupportedEncodingException {
        HashMap<Integer, HashMap<Integer, Integer>> mid_fid_map = new HashMap<>();
        for (int stid : stid_elements.keySet()) {
            Sent elem = stid_elements.get(stid);
            for (int i = 0; i < elem.size; i++) {
                int fid = crfid_fid[elem.crfid_al.get(i)];
                int mid = emid_mid[elem.emid_al.get(i)];
                if (!mid_fid_map.containsKey(mid))
                    mid_fid_map.put(mid, new HashMap<>());
                Integer cnt = mid_fid_map.get(mid).get(fid);
                mid_fid_map.get(mid).put(fid, cnt == null ? 1 : cnt + 1);
            }
        }
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "m_f_" + cat + ".txt"), "UTF-8"));
        for (int mid : mid_fid_map.keySet()) {
            if (mid_fid_map.get(mid).size() > 1) {
                System.out.println(mid_m.get(mid));
                ArrayList<Integer> fid_rank = Utility.rankDescendII(mid_fid_map.get(mid));
                for (int fid : fid_rank) {
                    System.out.println("\t" + fid_f.get(fid) + "\t" + mid_fid_map.get(mid).get(fid));
                }
                out.println(mid_m.get(mid) + "\t" + fid_f.get(fid_rank.get(0)));
            }
        }
        out.close();
    }

    public void crfIDDiverse() throws InterruptedException, FileNotFoundException, UnsupportedEncodingException {
        HashMap<Integer, Double> crfid_diverse = new HashMap<>();
        for (int crfid = 0; crfid < CRF; crfid++) {
            double diverse = 0;
            int eid_cnt = 0;
            if (!crfid_eid_emid_cnt.containsKey(crfid)) {
                continue;
            }
            for (int eid : crfid_eid_emid_cnt.get(crfid).keySet()) {
                double diverse_e = 0;
                int cnt = 0;
                ArrayList<Integer> emid_al = new ArrayList<>();
                for (Map.Entry<Integer, Integer> entry : crfid_eid_emid_cnt.get(crfid).get(eid).entrySet()) {
                    for (int i = 0; i < entry.getValue(); i++)
                        emid_al.add(entry.getKey());
                }
                for (int i = 0; i < emid_al.size(); i++) {
                    for (int j = i + 1; j < emid_al.size(); j++) {
                        cnt++;
                        if (!emid_al.get(i).equals(emid_al.get(j)))
                            diverse_e++;
                    }
                }
                if (cnt != 0) {
                    diverse_e /= cnt;
                    diverse += diverse_e;
                    eid_cnt++;
                }
            }
            if (eid_cnt != 0) {
                diverse /= eid_cnt;
            }
            crfid_diverse.put(crfid, diverse);
        }
        ArrayList<Integer> crfid_rank = Utility.rankDescendID(crfid_diverse);
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "crf_diverse_" + cat + ".txt"), "UTF-8"));
        for (int i = 0; i < crfid_rank.size(); i++) {
            Integer crfid = crfid_rank.get(i);
            System.out.println(i + "\t" + crfid_crf.get(crfid) + "\t" + crfid_diverse.get(crfid));
            String f = fid_f.get(crfid_fid[crfid]);
            if (i > crfid_rank.size() / 10) break;
            if (!f.equals("NUMBER") && !f.equals("MONEY") && !f.equals("PERCENT") && !f.equals("DATE")) {
                out.println(crfid_crf.get(crfid));
                System.out.println("\t" + crfid_crf.get(crfid));
            }
        }
        out.close();
    }
    public static HashMap<String, Set<String>> getCategoryConcept(String dirPath) throws IOException {
        HashMap<String, HashMap<String, HashSet<String>>> cat_concept_doc_set = new HashMap<>();
        HashMap<String, HashMap<String, HashSet<String>>> cat_concept_val_set = new HashMap<>();
        HashMap<String, HashSet<String>> concept_cat = new HashMap<>();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath+"data.txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = in.readLine().split("\t");
            String doc = sl[0];
            String cat = sl[0].split("_")[0];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            in.readLine();
            if(!cat_concept_doc_set.containsKey(cat))
                cat_concept_doc_set.put(cat, new HashMap<>());
            if(!cat_concept_val_set.containsKey(cat))
                cat_concept_val_set.put(cat, new HashMap<>());

            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String concept = sl[0].split(":")[0];
                String value = sl[2];
                if(!cat_concept_doc_set.get(cat).containsKey(concept))
                    cat_concept_doc_set.get(cat).put(concept, new HashSet<>());
                if(!cat_concept_val_set.get(cat).containsKey(concept))
                    cat_concept_val_set.get(cat).put(concept, new HashSet<>());
                if(!concept_cat.containsKey(concept))
                    concept_cat.put(concept, new HashSet<>());
                cat_concept_doc_set.get(cat).get(concept).add(doc);
                cat_concept_val_set.get(cat).get(concept).add(value);
            }
            for (int i = 0; i < wCnt; i++)
                in.readLine();
        }
        in.close();
        for(String cat : cat_concept_doc_set.keySet()){
            for(String concept : cat_concept_doc_set.get(cat).keySet()) {
                if (cat_concept_doc_set.get(cat).get(concept).size() > 0) {
                    concept_cat.get(concept).add(cat);
                }
            }
        }

        //calculate concept entropy
        HashMap<String, Double> concept_entropy = new HashMap<>();
        for(String concept : concept_cat.keySet()){
            double[] cat_prob = new double[cat_concept_doc_set.size()];
            Arrays.fill(cat_prob, 0.01);
            for(String cat : concept_cat.get(concept)){
                cat_prob[Integer.valueOf(cat)] += cat_concept_doc_set.get(cat).get(concept).size();
            }
            double cnt = 0;
            for(double val : cat_prob)
                cnt += val;
//            if(cnt < 5)
//                System.out.println(concept+"\t"+cnt);
            Utility.normalizeL1(cat_prob);
            double entropy = 0;
            for(int cat = 0; cat < cat_prob.length; cat++) {
                entropy -= cat_prob[cat] * Math.log(cat_prob[cat]);
            }
            concept_entropy.put(concept, entropy);
        }
        HashMap<String, Set<String>> cat_concept_valid = new HashMap<>();
        IDictionary dict;
        URL url = new URL("file", null, dictPath);
        dict = new edu.mit.jwi.Dictionary(url);
        dict.open();
        for(String cat : cat_concept_doc_set.keySet()){
            System.out.println("category: "+cat);
            HashMap<String, Double> concept_tfentropy = new HashMap<>();
            HashMap<String, Double> concept_tfentropy_valid = new HashMap<>();
            HashMap<String, HashSet<String>> concept_doc_set = cat_concept_doc_set.get(cat);
            HashMap<String, HashSet<String>> concept_value_set = cat_concept_val_set.get(cat);
            for(String concept : concept_doc_set.keySet()){
                double tf = concept_doc_set.get(concept).size();
                double entropy = concept_entropy.get(concept);
                double tfentropy = tf / entropy;
                concept_tfentropy.put(concept, tfentropy);
            }
            ArrayList<String> concept_al = Utility.rankDescendSD(concept_tfentropy);
            for(int i = 0; i < concept_al.size(); i++){
                String concept = concept_al.get(i);
                double tfentropy = concept_tfentropy.get(concept);
                if(i < 100){
                    concept_tfentropy_valid.put(concept, tfentropy);
                    HashSet<String> syn_set = getSynonyms(dict, concept);
                    for(String concept_syn : syn_set){
                        if(concept_tfentropy.containsKey(concept_syn) && Utility.commonEntryS(concept_value_set.get(concept), concept_value_set.get(concept_syn)).size() > 4){
                            concept_tfentropy_valid.put(concept_syn, concept_tfentropy.get(concept_syn));
                        }
                    }
                }
            }
            cat_concept_valid.put(cat, concept_tfentropy_valid.keySet());
            concept_al = Utility.rankDescendSD(concept_tfentropy_valid);
            for(int i = 0; i < concept_al.size(); i++) {
                String concept = concept_al.get(i);
                double tfidf = concept_tfentropy.get(concept);
                System.out.println("\t" + i + "\t" + concept + "\t" + tfidf);
            }
        }
        dict.close();
        return cat_concept_valid;
    }

    public static HashSet<String> getSynonyms(IDictionary dict, String concept) throws IOException {
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(concept, POS.VERB), dict.getIndexWord(concept, POS.NOUN)};
        HashSet<String> syn_set = new HashSet<>();
        for(IIndexWord idxWord : idxWord_al){       //for each POS
            if(idxWord == null)
                continue;
            for(IWordID wordID : idxWord.getWordIDs()){     //for each current word
                IWord word = dict.getWord(wordID);
                for (IWord w : word.getSynset().getWords()) {       //add its synonyms
                    if(w.getLemma().contains("_"))
                        continue;
                    syn_set.add(w.getLemma());
                }
                for(IWordID wordID_rel : word.getRelatedWords()){       //for each related word of current word
                    IWord word_rel = dict.getWord(wordID_rel);
                    if(word_rel.getLemma().contains("_") || word_rel.getLemma().length() < 2 || word.getLemma().length() < 2 || !word_rel.getLemma().substring(0, 2).equals(word.getLemma().substring(0, 2))) continue;
                    if(!(word_rel.getPOS() == POS.VERB || word_rel.getPOS() == POS.NOUN))continue;
                    syn_set.add(word_rel.getLemma());       //add it as synonyms
                    for (IWord w : word_rel.getSynset().getWords()) {       //for each synonym of current related word
                        if(w.getLemma().contains("_"))
                            continue;
                        syn_set.add(w.getLemma());
                    }
                }
            }
        }
        return syn_set;
    }
    public static void transform(String dirPath) throws IOException {
        HashMap<String, Set<String>> cat_concept_valid = getCategoryConcept(dirPath);
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data.txt"), "UTF-8"));
        String s;
        ArrayList<String> text_al = new ArrayList<>();
        while ((s = in.readLine()) != null) {
            text_al.add(s);
        }
        in.close();


        HashMap<String, Integer> st_valid = new HashMap<>();
        for(int i = 0; i < text_al.size(); i++){
            i++;
            s = text_al.get(i);
            String[] sl = s.split("\t");
            String cat = sl[0].split("_")[0];
            String st = sl[0]+"_"+sl[2];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            ++i;
            int valid_cnt = 0;
            for (int j = 0; j < tpCnt; j++) {
                s = text_al.get(++i);
                sl = s.split("\t");
                String concept = sl[0].split(":")[0];
                if(cat_concept_valid.get(cat).contains(concept))
                    valid_cnt++;
            }
            if(valid_cnt > 0)
                st_valid.put(st, valid_cnt);
            for (int j = 0; j < wCnt; j++) {
                ++i;
            }
        }
//        for(String st : st_valid.keySet())
//            System.out.println(st+"\t"+st_valid.get(st));
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "data_total.txt"), "UTF-8"));
        for(int c = 0; c < 5; c++){
            String cat_target = String.valueOf(c);
//            PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "data_cat_new_"+cat_target+".txt"), "UTF-8"));
            for(int i = 0; i < text_al.size(); i++){
                i++;
                s = text_al.get(i);
                System.out.println(s);
                String[] sl = s.split("\t");
                String cat = sl[0].split("_")[0];
                String st = sl[0]+"_"+sl[2];
                Integer tpCnt = Integer.valueOf(sl[4]);
                Integer wCnt = Integer.valueOf(sl[5]);
                if(!cat.equals(cat_target) || !st_valid.containsKey(st)) {
                    i++;
                    for (int j = 0; j < tpCnt + wCnt; j++)
                        i++;
                    continue;
                }
                out.println("*************");
                out.println(sl[0]+"\t"+sl[1]+"\t"+sl[2]+"\t"+sl[3]+"\t"+st_valid.get(st)+"\t"+sl[5]);

                out.println(text_al.get(++i));

                for (int j = 0; j < tpCnt; j++) {
                    s = text_al.get(++i);
                    sl = s.split("\t");
                    String concept = sl[0].split(":")[0];
                    if(cat_concept_valid.get(cat).contains(concept))
                        out.println(s);
                }
                for (int j = 0; j < wCnt; j++) {
                    s = text_al.get(++i);
                    out.println(s);
                }
            }
//            out.close();
        }
        out.close();
    }
    public static void main(String[] args) throws InterruptedException, ParseException, IOException {
        String dirPath = "";
//        findCRFEventMapping(dirPath+"data.txt", "4");
//        PreRemoval pr = new PreRemoval(dirPath);
//        pr.getValidConcept();
//        pr.transform();
//        transform(dirPath);
        for (int step = 0; step < 4; step++) {
            for(int cat = 0; cat < 5; cat++) {
                FilePreparation db = new FilePreparation(dirPath, cat);
                db.convertRawFile(step);
            }
        }
    }
}
