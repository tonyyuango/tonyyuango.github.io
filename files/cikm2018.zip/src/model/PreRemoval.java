package model;

import edu.mit.jwi.IDictionary;
import edu.mit.jwi.item.IIndexWord;
import edu.mit.jwi.item.IWord;
import edu.mit.jwi.item.IWordID;
import edu.mit.jwi.item.POS;
import util.Utility;

import java.io.*;
import java.net.URL;
import java.util.*;

/**
 * Created by quanyuan on 2/15/17.
 */
public class PreRemoval {
    String dictPath = "../WordNet-3.0/dict/";
    String dirPath;
    public PreRemoval(String dirPath) {
        this.dirPath = dirPath;
    }
    HashMap<String, HashSet<String>> cat_invalid_crf = new HashMap<>();
    private HashSet<String> findCRFEventMapping(String dataPath, String catTarget) throws IOException {
        HashSet<String> eventSet = new HashSet<>();
        HashMap<String, HashSet<String>> crf_event = new HashMap<>();
        HashMap<String, HashMap<String, HashMap<String, Integer>>> crf_event_value_cnt = new HashMap<>();

        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dataPath), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = in.readLine().split("\t");
            String cat = sl[0].substring(0, sl[0].indexOf("_"));
            String event = sl[0].substring(0, sl[0].lastIndexOf("_"));
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            in.readLine();
            if (!cat.equals(catTarget)) {
                for (int i = 0; i < tpCnt; i++) {
                    in.readLine();
                }
            } else {
                eventSet.add(event);
                for (int i = 0; i < tpCnt; i++) {
                    s = in.readLine();
                    sl = s.split("\t");
                    String crf = sl[0]+":"+sl[1];
                    String value = sl[2];
                    if (!crf_event.containsKey(crf)) {
                        crf_event.put(crf, new HashSet<>());
                        crf_event_value_cnt.put(crf, new HashMap<>());
                    }
                    crf_event.get(crf).add(event);
                    if (!crf_event_value_cnt.get(crf).containsKey(event)) {
                        crf_event_value_cnt.get(crf).put(event, new HashMap<>());
                    }
                    crf_event_value_cnt.get(crf).get(event).put(value, crf_event_value_cnt.get(crf).get(event).getOrDefault(value, 0) + 1);
                }
            }
            for (int i = 0; i < wCnt; i++) {
                in.readLine();
            }
        }
        in.close();

        HashMap<String, Integer> crf_eventCnt = new HashMap<>();
        for (String crf : crf_event.keySet()) {
            crf_eventCnt.put(crf, crf_event.get(crf).size());
        }
        HashMap<String, Double> crf_entropy = new HashMap<>();
        for (String crf : crf_event_value_cnt.keySet()) {
            double entropy = 0;
            for (String event : crf_event_value_cnt.get(crf).keySet()) {
                HashMap<String, Integer> value_cnt = crf_event_value_cnt.get(crf).get(event);
                double[] dist = new double[value_cnt.size()];
                int i = 0;
                for (String value : value_cnt.keySet()) {
                    dist[i++] = value_cnt.get(value);
                }
                Utility.normalizeL1(dist);
                double entropyEvent = 0;
                for (int j = 0; j < dist.length; j++) {
                    entropyEvent -= dist[j] * Math.log(dist[j]);
                }
                entropy += entropyEvent;
            }
            entropy /= crf_event_value_cnt.get(crf).size();
            crf_entropy.put(crf, entropy);
        }
        HashSet<String> crf_valid = new HashSet<>();
        ArrayList<String> crf_cnt_rank = Utility.rankDescendSI(crf_eventCnt);
        cat_invalid_crf.put(catTarget, new HashSet<>());
        for (int i = 0; i < crf_cnt_rank.size(); i++) {
            String crf = crf_cnt_rank.get(i);
            if (crf_eventCnt.get(crf) >= eventSet.size() / 2 && crf_entropy.get(crf) < 2) {
//                System.out.println(i + "\t" + crf + "\t" + crf_eventCnt.get(crf) + "\t" + crf_entropy.get(crf));
                crf_valid.add(crf);
            } else {
                cat_invalid_crf.get(catTarget).add(crf);
            }
        }
        return crf_valid;
    }
    private HashMap<String, Set<String>> getEventConcept() throws IOException {
        HashMap<String, Set<String>> ans = new HashMap<>();
        for (String cat : new String[]{"0", "1", "2", "3", "4"}) {
            ans.put(cat, new HashSet<>());
            HashSet<String> crfSet = findCRFEventMapping(dirPath + "data.txt", cat);
            for (String crf : crfSet) {
                ans.get(cat).add(crf.substring(0, crf.indexOf(":")));
            }
        }
        return ans;
    }

    public HashMap<String, Set<String>> getCategoryConcept() throws IOException {
        HashMap<String, HashMap<String, HashSet<String>>> cat_concept_doc_set = new HashMap<>();
        HashMap<String, HashSet<String>> concept_cat = new HashMap<>();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data.txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = in.readLine().split("\t");
            String doc = sl[0];
            String cat = sl[0].split("_")[0];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            in.readLine();
            if(!cat_concept_doc_set.containsKey(cat))
                cat_concept_doc_set.put(cat, new HashMap<>());

            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String concept = sl[0].split(":")[0];
                String value = sl[2];
                if(!cat_concept_doc_set.get(cat).containsKey(concept))
                    cat_concept_doc_set.get(cat).put(concept, new HashSet<>());
                if(!concept_cat.containsKey(concept))
                    concept_cat.put(concept, new HashSet<>());
                cat_concept_doc_set.get(cat).get(concept).add(doc);
            }
            for (int i = 0; i < wCnt; i++)
                in.readLine();
        }
        in.close();
        for(String cat : cat_concept_doc_set.keySet()){
            for(String concept : cat_concept_doc_set.get(cat).keySet()) {
                if (cat_concept_doc_set.get(cat).get(concept).size() > 0) {
                    concept_cat.get(concept).add(cat);
                }
            }
        }

        //calculate concept entropy
        HashMap<String, Double> concept_entropy = new HashMap<>();
        for(String concept : concept_cat.keySet()){
            double[] cat_prob = new double[cat_concept_doc_set.size()];
            Arrays.fill(cat_prob, 0.01);
            for(String cat : concept_cat.get(concept)){
                cat_prob[Integer.valueOf(cat)] += cat_concept_doc_set.get(cat).get(concept).size();
            }
            double cnt = 0;
            for(double val : cat_prob)
                cnt += val;
            Utility.normalizeL1(cat_prob);
            double entropy = 0;
            for(int cat = 0; cat < cat_prob.length; cat++) {
                entropy -= cat_prob[cat] * Math.log(cat_prob[cat]);
            }
            concept_entropy.put(concept, entropy);
        }
        HashMap<String, Set<String>> cat_concept_valid = new HashMap<>();
        for(String cat : cat_concept_doc_set.keySet()){
//            System.out.println("category: "+cat);
            HashMap<String, Double> concept_tfentropy = new HashMap<>();
            HashMap<String, Double> concept_tfentropy_valid = new HashMap<>();
            HashMap<String, HashSet<String>> concept_doc_set = cat_concept_doc_set.get(cat);
            for(String concept : concept_doc_set.keySet()){
                double tf = concept_doc_set.get(concept).size();
                double entropy = concept_entropy.get(concept);
                double tfentropy = tf / entropy;
                concept_tfentropy.put(concept, tfentropy);
            }
            ArrayList<String> concept_al = Utility.rankDescendSD(concept_tfentropy);
            for(int i = 0; i < concept_al.size(); i++){
                String concept = concept_al.get(i);
                double tfentropy = concept_tfentropy.get(concept);
                if(i < 100){
                    concept_tfentropy_valid.put(concept, tfentropy);
                }
            }
            cat_concept_valid.put(cat, concept_tfentropy_valid.keySet());
        }
        return cat_concept_valid;
    }
    public HashMap<String, Set<String>> getValidConcept() throws IOException {
        HashMap<String, Set<String>> cat_concept_cat = getCategoryConcept();
        HashMap<String, Set<String>> cat_concept_event = getEventConcept();
        HashMap<String, Set<String>> cat_concept = new HashMap<>();
        for (String cat : cat_concept_cat.keySet()) {
            Set<String> set = new HashSet<>(cat_concept_cat.get(cat));
            set.retainAll(cat_concept_event.get(cat));
            cat_concept.put(cat, set);
        }
        //add synonyms
        HashMap<String, HashSet<String>> concept_value_set = new HashMap<>();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data.txt"), "UTF-8"));
        String s;
        while ((s = in.readLine()) != null) {
            String[] sl = in.readLine().split("\t");
            String doc = sl[0];
            String cat = sl[0].split("_")[0];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            in.readLine();
            for (int i = 0; i < tpCnt; i++) {
                s = in.readLine();
                sl = s.split("\t");
                String concept = sl[0].split(":")[0];
                String value = sl[2];
                if (!concept_value_set.containsKey(concept)) {
                    concept_value_set.put(concept, new HashSet<>());
                }
                concept_value_set.get(concept).add(value);
            }
            for (int i = 0; i < wCnt; i++)
                in.readLine();
        }
        in.close();
        IDictionary dict;
        URL url = new URL("file", null, dictPath);
        dict = new edu.mit.jwi.Dictionary(url);
        dict.open();
        for(String cat : cat_concept.keySet()) {
            System.out.println(cat);
            HashSet<String> additonal = new HashSet<>();
            for (String concept : cat_concept.get(cat)) {
                HashSet<String> syn_set = getSynonyms(dict, concept);
                for (String concept_syn : syn_set) {
                    if (concept_value_set.containsKey(concept_syn) && Utility.commonEntryS(concept_value_set.get(concept), concept_value_set.get(concept_syn)).size() > 4) {
                        additonal.add(concept_syn);
                    }
                }
            }
            cat_concept.get(cat).addAll(additonal);
            for (String concept : cat_concept.get(cat)) {
                System.out.println("\t" + concept);
            }
        }
        return cat_concept;
    }
    public static HashSet<String> getSynonyms(IDictionary dict, String concept) throws IOException {
        IIndexWord[] idxWord_al = new IIndexWord[]{dict.getIndexWord(concept, POS.VERB), dict.getIndexWord(concept, POS.NOUN)};
        HashSet<String> syn_set = new HashSet<>();
        for(IIndexWord idxWord : idxWord_al){       //for each POS
            if(idxWord == null)
                continue;
            for(IWordID wordID : idxWord.getWordIDs()){     //for each current word
                IWord word = dict.getWord(wordID);
                for (IWord w : word.getSynset().getWords()) {       //add its synonyms
                    if(w.getLemma().contains("_"))
                        continue;
                    syn_set.add(w.getLemma());
                }
                for(IWordID wordID_rel : word.getRelatedWords()){       //for each related word of current word
                    IWord word_rel = dict.getWord(wordID_rel);
                    if(word_rel.getLemma().contains("_") || word_rel.getLemma().length() < 2 || word.getLemma().length() < 2 || !word_rel.getLemma().substring(0, 2).equals(word.getLemma().substring(0, 2))) continue;
                    if(!(word_rel.getPOS() == POS.VERB || word_rel.getPOS() == POS.NOUN))continue;
                    syn_set.add(word_rel.getLemma());       //add it as synonyms
                    for (IWord w : word_rel.getSynset().getWords()) {       //for each synonym of current related word
                        if(w.getLemma().contains("_"))
                            continue;
                        syn_set.add(w.getLemma());
                    }
                }
            }
        }
        return syn_set;
    }
    public void transform() throws IOException {
        HashMap<String, Set<String>> cat_concept_valid = getValidConcept();
        BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(dirPath + "data.txt"), "UTF-8"));
        String s;
        ArrayList<String> text_al = new ArrayList<>();
        while ((s = in.readLine()) != null) {
            text_al.add(s);
        }
        in.close();


        HashMap<String, Integer> st_valid = new HashMap<>();
        for(int i = 0; i < text_al.size(); i++){
            i++;
            s = text_al.get(i);
            String[] sl = s.split("\t");
            String cat = sl[0].split("_")[0];
            String st = sl[0]+"_"+sl[2];
            Integer tpCnt = Integer.valueOf(sl[4]);
            Integer wCnt = Integer.valueOf(sl[5]);
            ++i;
            int valid_cnt = 0;
            for (int j = 0; j < tpCnt; j++) {
                s = text_al.get(++i);
                sl = s.split("\t");
                String concept = sl[0].split(":")[0];
                String crf = sl[0]+":"+sl[1];
                if(cat_concept_valid.get(cat).contains(concept) && !cat_invalid_crf.get(cat).contains(crf))
                    valid_cnt++;
            }
            if(valid_cnt > 0)
                st_valid.put(st, valid_cnt);
            for (int j = 0; j < wCnt; j++) {
                ++i;
            }
        }
        PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "data_total.txt"), "UTF-8"));
        for(int c = 0; c < 5; c++){
            String cat_target = String.valueOf(c);
//            PrintWriter out = new PrintWriter(new OutputStreamWriter(new FileOutputStream(dirPath + "data_cat_new_"+cat_target+".txt"), "UTF-8"));
            for(int i = 0; i < text_al.size(); i++){
                i++;
                s = text_al.get(i);
                String[] sl = s.split("\t");
                String cat = sl[0].split("_")[0];
                String st = sl[0]+"_"+sl[2];
                Integer tpCnt = Integer.valueOf(sl[4]);
                Integer wCnt = Integer.valueOf(sl[5]);
                if(!cat.equals(cat_target) || !st_valid.containsKey(st)) {
                    i++;
                    for (int j = 0; j < tpCnt + wCnt; j++)
                        i++;
                    continue;
                }
                out.println("*************");
                out.println(sl[0]+"\t"+sl[1]+"\t"+sl[2]+"\t"+sl[3]+"\t"+st_valid.get(st)+"\t"+sl[5]);

                out.println(text_al.get(++i));

                for (int j = 0; j < tpCnt; j++) {
                    s = text_al.get(++i);
                    sl = s.split("\t");
                    String concept = sl[0].split(":")[0];
                    String crf = sl[0]+":"+sl[1];
                    if(cat_concept_valid.get(cat).contains(concept) && !cat_invalid_crf.get(cat).contains(crf))
                        out.println(s);
                }
                for (int j = 0; j < wCnt; j++) {
                    s = text_al.get(++i);
                    out.println(s);
                }
            }
//            out.close();
        }
        out.close();
    }
}
