package evaluation;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

/**
 * Created by quanyuan on 2/19/17.
 */
public class Evaluation {
    int[] groundTruth = new int[]{10, 10, 10, 10, 10};
    HashMap<String, HashSet<Integer>> f_rank = new HashMap<>();
    HashMap<String, Integer> f_length = new HashMap<>();
    public void readResult(String filePath) throws IOException {
        BufferedReader in = new BufferedReader(new FileReader(filePath));
        String s;
        HashSet<Integer> rank= new HashSet<>();
        String f = null;
            while ((s = in.readLine()) != null) {
            if (s.charAt(0) == '*') {
                if (f != null) {
                    f_rank.put(f, new HashSet<>(rank));
                    rank.clear();
                }
                s = in.readLine();
                f = s.split("\t")[0];
                f_length.put(f, Integer.valueOf(s.split("\t")[1]));
            } else {
                rank.add(Integer.valueOf(s));
            }
        }
        f_rank.put(f, rank);
        in.close();
        System.out.println(f_rank);
    }

    public void printResult() {
        for (int i = 0; i < 5; i++) {
            System.out.println(i);
            HashSet<Integer> set = new HashSet<>();
            for (int j = 0; j < groundTruth[i]; j++) {
                set.add(j);
            }
            for (String prefix : new String[]{"a_", "b_", "c_", "d_"}) {
                String f = prefix + i;
                ArrayList<Integer> result_al = new ArrayList<>();
                for (int k = 0; k < f_length.get(f); k++) {
                    if (f_rank.get(f).contains(k)) {
                        result_al.add(k);
                    } else {
                        result_al.add(-1);
                    }
                }
                double map = averagePresision(result_al, set);
                double ndcg = nDCG(result_al, set);
                System.out.println(map + "\t" + ndcg);
            }
        }
    }
    public static double nDCG(List<Integer> result_al, Set<Integer> true_set){
        Double DCG = 0.0;
        if(true_set.contains(result_al.get(0)))
            DCG += 1.0;
        for(int i = 1; i < result_al.size(); i++){
            if(true_set.contains(result_al.get(i))){
                DCG += 1.0/(Math.log(i+1) / Math.log(2));
            }
        }
        double denominator = 1;
        for (int i = 2; i <= result_al.size(); i++) {
            denominator += Math.log(2) / Math.log(i);
        }
        return DCG / denominator;
    }
    private static double precision(List<Integer> result_al, Set<Integer> true_set, int k){
        int tp = 0;
        for(int i = 0; i < k; i++){
            if(true_set.contains(result_al.get(i))){
                tp++;
            }
        }
        return 1.0 * tp / k;
    }

    private static double averagePresision(List<Integer> result_al, Set<Integer> true_set){
        double ap = 0;
        for(int k = 1; k <= result_al.size(); k++){
            ap += precision(result_al, true_set, k);
        }
//        double min = result_al.size() > true_set.size() ? true_set.size() : result_al.size();
        double min = result_al.size();
        return ap / min;
    }
    public static void main(String[] args) throws IOException {
        String filePath = "";
        Evaluation e = new Evaluation();
        e.readResult(filePath);
        e.printResult();
    }
}
