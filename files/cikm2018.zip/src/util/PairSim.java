package util;

/**
 * Created by quanyuan on 9/21/16.
 */
public class PairSim implements Comparable<PairSim>{
    Pair p;
    double sim;

    public PairSim(Integer id1, Integer id2, double sim) {
        this.p = new Pair(id1, id2);
        this.sim = sim;
    }
    public int getID1(){
        return p.id1;
    }
    public int getID2(){
        return p.id2;
    }
    public double getSim(){
        return sim;
    }
    public Pair getPair(){
        return p;
    }
    @Override
    public String toString() {
        return "PairSim{" +
                "p=" + p +
                ", sim=" + sim +
                '}';
    }

    @Override
    public int compareTo(PairSim o) {
        if(sim < o.sim)
            return 1;
        else if(sim > o.sim)
            return -1;
        else
            return 0;
    }
}
