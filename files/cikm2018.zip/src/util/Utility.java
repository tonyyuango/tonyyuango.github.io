package util;

import java.util.*;
import java.util.Map.Entry;

/**
 * Created by quanyuan on 8/2/16.
 */
public class Utility {
    public static double dotProduct(HashMap<Integer, Integer> map1, HashMap<Integer, Integer> map2){
        int product = 0;
        for(Integer key : map1.keySet()){
            if(map2.containsKey(key))
                product += map1.get(key) * map2.get(key);
        }
        return product;
    }
    public static double vectorProduct(double[] v1, double[] v2){
        double product = 0;
        for(int i = 0; i < v1.length; i++)
            product += v1[i] * v2[i];
        return product;
    }

    public static double Jaccard(Set<Integer> set1, Set<Integer> set2){
        HashSet<Integer> intersect = new HashSet<>(set1);
        HashSet<Integer> union = new HashSet<>(set1);
        intersect.retainAll(set2);
        union.addAll(set2);
        if(union.size() == 0)
            return 0;
        return 1.0 * intersect.size() / union.size();
    }
    public static double[] randVec(int K, Random rand){
        double[] vec = new double[K];
        for(int k = 0; k < K; k++)
            vec[k] = Math.abs(rand.nextDouble());
        return vec;
    }
    public static HashSet<String> commonEntryS(HashSet<String> set1, HashSet<String> set2){
        HashSet<String> set_r = new HashSet<>();
        for(String entry : set1)
            if(set2.contains(entry))
                set_r.add(entry);
        return set_r;
    }
    public static HashSet<Integer> commonEntryI(ArrayList<Integer> al1, ArrayList<Integer> al2){
        Set<Integer> set1 = new HashSet<>(al1);
        Set<Integer> set2 = new HashSet<>(al2);
        HashSet<Integer> set_r = new HashSet<>();
        for(Integer entry : set1)
            if(set2.contains(entry))
                set_r.add(entry);
        return set_r;
    }
    public static HashSet<Integer> commonEntryI(Set<Integer> set1, Set<Integer> set2){
        if(set1 == null || set2 == null)
            return new HashSet<>();
        HashSet<Integer> set_r = new HashSet<>();
        for(Integer entry : set1)
            if(set2.contains(entry))
                set_r.add(entry);
        return set_r;
    }
    public static int recordCnt(String key, Integer key_cnt, HashMap<String, Integer> map){
        Integer cnt = map.containsKey(key) ? map.get(key) + key_cnt : key_cnt;
        map.put(key, cnt);
        return cnt;
    }
    public static int recordCnt(Integer key, Integer key_cnt, HashMap<Integer, Integer> map){
        Integer cnt = map.containsKey(key) ? map.get(key) + key_cnt : key_cnt;
        map.put(key, cnt);
        return cnt;
    }
    public static int getID(String key, HashMap<String, Integer> key_id, HashMap<Integer, String> id_key){
        if(!key_id.containsKey(key)){
            int id = key_id.size();
            key_id.put(key, id);
            id_key.put(id, key);
        }
        return key_id.get(key);
    }
    public static int getID(Integer key, HashMap<Integer, Integer> key_id, HashMap<Integer, Integer> id_key){
        if(!key_id.containsKey(key)){
            int id = key_id.size();
            key_id.put(key, id);
            id_key.put(id, key);
        }
        return key_id.get(key);
    }
    public static double[][] copyMatrix(double[][] m){
        double[][] n = new double[m.length][];
        for(int i = 0; i < m.length; i++)
            n[i] = Arrays.copyOf(m[i], m[i].length);
        return n;
    }
    public static double[] randomVec(double x, int K, Random rand){
        double[] vec = new double[K];
        for(int i = 0; i < K; i++)
            vec[i] = rand.nextDouble() * (rand.nextDouble() > 0.5 ? 1 : -1) % (x/Math.sqrt(K));
        return vec;
    }
    public static int sample(double[] weight, Random rand, double total_sum){
        double r = Math.abs(rand.nextDouble()) * total_sum;
        int idx = 0;
        double sum = 0;
        while(sum + weight[idx] < r){
            sum += weight[idx];
            idx++;
        }
        return idx;
    }
    public static void maxMinNormalize(HashMap<String, Double> map){
        double max = 0;
        double min = Double.MAX_VALUE;
        for(Entry<String, Double> entry : map.entrySet()){
            if(entry.getValue() > max)
                max = entry.getValue();
            if(entry.getValue() < min)
                min = entry.getValue();
        }
        min = 0.000001;
        if(max > min){
            for(Entry<String, Double> entry : map.entrySet()){
                Double value_new = (entry.getValue() - min) / (max - min);
                if(value_new < 0){
                    System.err.println(entry.getValue()+"\t"+min+"\t"+max+"\t"+value_new);
                }
                entry.setValue((entry.getValue() - min) / (max - min));
            }
        }else{
            System.err.println("MAX == MIN!!!");
            for(Entry<String, Double> entry : map.entrySet())
                entry.setValue(0.5);
        }
    }
    public static void setZero(Double[][] m){
        for(int i = 0; i < m.length; i++)
            Arrays.fill(m[i], 0.0);
    }
    public static Double[] vectorTimes(Double[] p, Double t) {
        Double[] r = new Double[p.length];
        for (int i = 0; i < p.length; i++)
            r[i] = p[i] * t;
        return r;
    }
    public static int max(int a, int b){
        return a>b?a:b;
    }
    public static double max(double a, double b){
        return a>b?a:b;
    }
    public static int min(int a, int b){
        return a>b?b:a;
    }
    public static Double min(Double a, Double b){
        return a>b?b:a;
    }
    public static double[] vectorAdd(double[] p, double[] q) {
        double[] r = new double[p.length];
        for (int i = 0; i < p.length; i++)
            r[i] = p[i] + q[i];
        return r;
    }
    public static Double[] vectorAdd(Double[] p, Double[] q) {
        Double[] r = new Double[p.length];
        for (int i = 0; i < p.length; i++)
            r[i] = p[i] + q[i];
        return r;
    }
    //	public static double cosine(double[] v1, double[] v2){
//		double sim = 0;
//		for(int i = 0; i < v1.length; i++)
//			sim+= v1[i] * v2[i];
//		return sim;
//	}
    public static double cosine_full(double[] v1, double[] v2){
        double numerator = 0.0, denominatorV1 = 0.0, denominatorV2 = 0.0;
        for(int i = 0; i < v1.length; i++){
            numerator += v1[i] * v2[i];
            denominatorV1 += v1[i]*v1[i];
            denominatorV2 += v2[i]*v2[i];
        }
        if(denominatorV1 == 0 || denominatorV2 == 0)
            return 0;
        else
            return numerator / Math.sqrt(denominatorV1) / Math.sqrt(denominatorV2);
    }
    public static int min_cover(HashMap<String, Integer> map1, HashMap<String, Integer> map2){
        int result = 0;
        for(String key : map1.keySet()){
            if(map2.containsKey(key)){
                result += min(map1.get(key), map2.get(key));
            }
        }
        return result;
    }
    public static int min_coverII(HashMap<Integer, Integer> map1, HashMap<Integer, Integer> map2){
        int result = 0;
        for(Integer key : map1.keySet()){
            if(map2.containsKey(key)){
                result += min(map1.get(key), map2.get(key));
            }
        }
        return result;
    }
    public static double min_coverID(HashMap<Integer, Double> map1, HashMap<Integer, Double> map2){
        double result = 0;
        for(Integer key : map1.keySet()){
            if(map2.containsKey(key)){
                result += min(map1.get(key), map2.get(key));
            }
        }
        return result;
    }
    public static double cosine_fullSI(HashMap<String, Integer> map1, HashMap<String, Integer> map2){
        double numerator = 0, denominator1 = 0, denominator2 = 0;
        for(String key : map1.keySet())
            if(map2.containsKey(key))
                numerator += map1.get(key) * map2.get(key);
        for(String key : map1.keySet())
            denominator1 += map1.get(key) * map1.get(key);
        for(String key : map2.keySet())
            denominator2 += map2.get(key) * map2.get(key);
        return numerator / Math.sqrt(denominator1) / Math.sqrt(denominator2);
    }
    public static double cosine_fullII(HashMap<Integer, Integer> map1, HashMap<Integer, Integer> map2){
        double numerator = 0, denominator1 = 0, denominator2 = 0;
        for(Integer key : map1.keySet())
            if(map2.containsKey(key))
                numerator += map1.get(key) * map2.get(key);
        for(Integer key : map1.keySet())
            denominator1 += map1.get(key) * map1.get(key);
        for(Integer key : map2.keySet())
            denominator2 += map2.get(key) * map2.get(key);
        if(numerator == 0)
            return 0;
        else
            return numerator / Math.sqrt(denominator1) / Math.sqrt(denominator2);
    }
    public static double cosine_full(Double[] v1, Double[] v2){
        double numerator = 0.0, denominatorV1 = 0.0, denominatorV2 = 0.0;
        for(int i = 0; i < v1.length; i++){
            numerator += v1[i] * v2[i];
            denominatorV1 += v1[i]*v1[i];
            denominatorV2 += v2[i]*v2[i];
        }
        if(denominatorV1 == 0 || denominatorV2 == 0)
            return 0;
        else
            return numerator / Math.sqrt(denominatorV1) / Math.sqrt(denominatorV2);
    }
    public static double min_cover(Double[] v1, Double[] v2){
        double result = 0;
        for(int i = 0; i < v1.length; i++)
            result += min(v1[i], v2[i]);
        return result;
    }
    //	public static double min_cover(HashMap<Integer, Integer> map1, HashMap<Integer, Integer> map2){
//		double result = 0;
//		for(Integer key : map1.keySet()){
//			if(map2.containsKey(key)){
//				result += min(map1.get(key), map2.get(key));
//			}
//		}
//		return result;
//	}
    public static double gaussianDensity_1(double x, Double nu, Double lambda){
        double diff = x - nu;
        return Math.sqrt(lambda/2/Math.PI)*Math.exp(-lambda*diff*diff/2);
    }
    public static boolean normalizeL1(HashMap<Integer, Double> map){
        double sum = 0;
        for(Double val : map.values())
            sum += val;
        if(sum > 0){
            for(Entry<Integer, Double> entry : map.entrySet())
                entry.setValue(entry.getValue()/sum);
            return true;
        }else{
            return false;
        }
    }
    public static boolean normalizeL1(double[] a) {
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            if(Double.isInfinite(a[i]) || Double.isNaN(a[i])){
//                System.err.println("invalid prob: "+Arrays.toString(a));
                return false;
            }
        }

        for (int i = 0; i < a.length; i++) {
            sum += a[i];
        }
        if (sum != 0) {
            for (int i = 0; i < a.length; i++) {
                a[i] /= sum;
            }
            return true;
        } else {
//            System.err.println("zero denominator!!!");
            return false;
        }
    }
    public static boolean normalizeL2(double[] a) {
        double sum = 0.0;
        for (int i = 0; i < a.length; i++) {
            if(Double.isInfinite(a[i]) || Double.isNaN(a[i])){
                System.err.println("invalid prob: "+Arrays.toString(a));
                return false;
            }
        }

        for (int i = 0; i < a.length; i++) {
            sum += a[i] * a[i];
        }
        if (sum != 0) {
            for (int i = 0; i < a.length; i++) {
                a[i] /= sum;
            }
            return true;
        } else {
            System.err.println("zero denominator!!!");
            return false;
        }
    }
    public static int multinomial(HashMap<Integer, Double> map, Random rand){
        ArrayList<Integer> key_al = new ArrayList<>(map.keySet());
        double[] p = new double[key_al.size()];
        for(int i = 0; i < p.length; i++)
            p[i] = map.get(key_al.get(i));
        return key_al.get(multinomial(p, rand));
    }
    public static int multinomial(double[] p, Random rand) {
        // System.out.println(Arrays.toString(p));
        double r = Math.abs(rand.nextDouble());
        double sum = 0;
        for (int i = 0; i < p.length; i++) {
            sum += p[i];
            // System.out.println(r+"\t"+sum+"\t"+ (r < sum));
            if (r < sum)
                return i;
        }
        return p.length - 1;
    }

    public static int randAntoniak(double alpha, int n, Random rand) {
        int R = 20;
        double ainv = 1 / (alpha);
        double nt = 0;
        double[] p = new double[n];
        for (int r = 0; r < R; r++) {
            for (int m = 0; m < n; m++) {
                for (int t = 0; t < n; t++, nt += ainv) {
                    p[m] += randBernoulli(1 / (nt + 1), rand);
                }
            }
        }
        p = vectorTimes(p, 1. / R);
        return randMultDirect(p, rand) + 1;
    }

    public static int randMultDirect(double[] p, Random rand) {
        int i;
        double[] pp = Arrays.copyOf(p, p.length);
        for (i = 1; i < pp.length; i++) {
            pp[i] += pp[i - 1];

        }
        // this automatically normalises.
        double randNum = Math.abs(rand.nextDouble()) * pp[i - 1];
        i = binarySearch(pp, randNum);

        // System.out.println(Vectors.filtering(pp) + " " + i);

        return i;
    }
    public static boolean isEqual(Set<Integer> set1, Set<Integer> set2){
        for(int item : set1)
            if(!set2.contains(item))
                return false;
        for(int item : set2)
            if(!set1.contains(item))
                return false;
        return true;
    }
    public static int binarySearch(double[] a, double p) {
        if (p < a[0]) {
            return 0;
        }
        int low = 0;
        int high = a.length - 1;
        while (low <= high) {
            int mid = (low + high) >> 1;
            double midVal = a[mid];

            if (midVal < p) {
                low = mid + 1;
            } else if (midVal > p) {
                if (a[mid - 1] < p)
                    return mid;
                high = mid - 1;
            } else {
                return mid;
            }
        }
        // out of range.
        return a.length;
    }

    public static int randBernoulli(double p, Random rand) {
        double a = Math.abs(rand.nextDouble());
        if (a < p) {
            return 1;
        }
        return 0;
    }
    public static double[] randDir(double[] aa, Random rand) {
        double[] ww = randGamma(aa, rand);

        double sum = 0;
        for (int i = 0; i < ww.length; i++) {
            sum += ww[i];
        }
        for (int i = 0; i < ww.length; i++) {
            ww[i] /= sum;
        }
        return ww;
    }
    public static double[] randGamma(double[] aa, Random rand) {
        double[] gamma = new double[aa.length];
        for (int i = 0; i < gamma.length; i++) {
            gamma[i] = randGamma(aa[i], rand);
        }
        return gamma;
    }

    public static double randGamma(double rr, Random rand) {
        double bb, cc, dd;
        double uu, vv, ww, xx, yy, zz;

        if (rr <= 0.0) {
			/* Not well defined, set to zero and skip. */
            return 0.0;
        } else if (rr == 1.0) {
			/* Exponential */
            return -Math.log(Math.abs(rand.nextDouble()));
        } else if (rr < 1.0) {
			/* Use Johnks generator */
            cc = 1.0 / rr;
            dd = 1.0 / (1.0 - rr);
            while (true) {
                xx = Math.pow(rand.nextDouble(), cc);
                yy = xx + Math.pow(rand.nextDouble(), dd);
                if (yy <= 1.0) {
                    assert yy != 0 && xx / yy > 0;
                    return -Math.log(rand.nextDouble()) * xx / yy;
                }
            }
        } else { /* rr > 1.0 */
			/* Use bests algorithm */
            bb = rr - 1.0;
            cc = 3.0 * rr - 0.75;
            while (true) {
                uu = rand.nextDouble();
                vv = rand.nextDouble();
                ww = uu * (1.0 - uu);
                yy = Math.sqrt(cc / ww) * (uu - 0.5);
                xx = bb + yy;
                if (xx >= 0) {
                    zz = 64.0 * ww * ww * ww * vv * vv;
                    assert zz > 0 && bb != 0 && xx / bb > 0;
                    if ((zz <= (1.0 - 2.0 * yy * yy / xx))
                            || (Math.log(zz) <= 2.0 * (bb * Math.log(xx / bb) - yy))) {
                        return xx;
                    }
                }
            }
        }
    }

    public static double[] vectorTimes(double[] p, double t) {
        double[] q = new double[p.length];
        for (int i = 0; i < p.length; i++)
            q[i] = p[i] * t;
        return q;
    }

    public static double vectorSum(double[] p) {
        double sum = 0;
        for (int i = 0; i < p.length; i++)
            sum += p[i];
        return sum;
    }
    public static double TDisDensity(double x, double mu, double lambda, int nu){
        double result = 1;
        int nu_tmp = nu;
        if(nu_tmp % 2 == 0){
            nu_tmp -= 1;
            while(nu_tmp >= 3){
                result = result * nu_tmp / (nu_tmp-1);
                nu_tmp -= 2;
            }
            result = result / 2 / Math.sqrt(nu);
        }else{
            nu_tmp -= 1;
            while(nu_tmp >= 2){
                result = result * nu_tmp / (nu_tmp-1);
                nu_tmp -= 2;
            }
            result = result / Math.PI / Math.sqrt(nu);
        }
        double temp = result;
        result *= Math.pow((1 + lambda*(x-mu)*(x-mu)/nu), -1.0*(nu+1)/2);
        if(Double.isNaN(result) || result == 0){
            System.out.println(result);
            System.out.println(temp);
            System.out.println(Math.pow((1 + lambda*(x-mu)*(x-mu)/nu), -1.0*(nu+1)/2));
        }
        return result;
    }
    public static ArrayList<Integer> rankDescendID(double[] v) {
        Map<Integer, Double> map = new HashMap<Integer, Double>();
        for (int i = 0; i < v.length; i++) {
            map.put(i, v[i]);
        }
        return rankDescendID(map);
    }
    public static ArrayList<Integer> rankDescendII(int[] v) {
        HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
        for (int i = 0; i < v.length; i++) {
            map.put(i, v[i]);
        }
        return rankDescendII(map);
    }
    public static ArrayList<String> rankDescendSI(HashMap<String, Integer> map) {
        List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(
                map.entrySet());

        Collections.sort(list,
                new Comparator<Entry<String, Integer>>() {
                    public int compare(
                            Entry<String, Integer> o1,
                            Entry<String, Integer> o2) {
                        return o2.getValue().compareTo(
                                o1.getValue());
                    }
                });
        ArrayList<String> results = new ArrayList<String>();
        for (int i = 0; i < list.size(); i++) {
            results.add(list.get(i).getKey());
        }
        return results;
    }
    public static ArrayList<String> rankDescendSD(HashMap<String, Double> map) {
        List<Entry<String, Double>> list = new ArrayList<Entry<String, Double>>(
                map.entrySet());

        Collections.sort(list,
                new Comparator<Entry<String, Double>>() {
                    public int compare(
                            Entry<String, Double> o1,
                            Entry<String, Double> o2) {
                        return o2.getValue().compareTo(
                                o1.getValue());
                    }
                });
        ArrayList<String> results = new ArrayList<String>();
        for (int i = 0; i < list.size(); i++) {
            results.add(list.get(i).getKey());
        }
        return results;
    }
    public static ArrayList<Integer> rankDescendII(HashMap<Integer, Integer> map) {
        List<Entry<Integer, Integer>> list = new ArrayList<Entry<Integer, Integer>>(
                map.entrySet());

        Collections.sort(list,
                new Comparator<Entry<Integer, Integer>>() {
                    public int compare(
                            Entry<Integer, Integer> o1,
                            Entry<Integer, Integer> o2) {
                        return o2.getValue().compareTo(
                                o1.getValue());
                    }
                });
        ArrayList<Integer> results = new ArrayList<Integer>();
        for (int i = 0; i < list.size(); i++) {
            results.add(list.get(i).getKey());
        }
        return results;
    }
    public static ArrayList<Integer> rankDescendID(Map<Integer, Double> map) {
        List<Entry<Integer, Double>> list = new ArrayList<Entry<Integer, Double>>(
                map.entrySet());
        Collections.sort(list,
                new Comparator<Entry<Integer, Double>>() {
                    public int compare(
                            Entry<Integer, Double> o1,
                            Entry<Integer, Double> o2) {
                        return o2.getValue().compareTo(
                                o1.getValue());
                    }
                });
        ArrayList<Integer> results = new ArrayList<Integer>();
        for (int i = 0; i < list.size(); i++) {
            results.add(list.get(i).getKey());
        }
        return results;
    }
    static final double GAMMA_MINX = 1.e-12;
    static final double[] lanczos = { 0.99999999999999709182,
            57.156235665862923517, -59.597960355475491248,
            14.136097974741747174, -0.49191381609762019978,
            .33994649984811888699e-4, .46523628927048575665e-4,
            -.98374475304879564677e-4, .15808870322491248884e-3,
            -.21026444172410488319e-3, .21743961811521264320e-3,
            -.16431810653676389022e-3, .84418223983852743293e-4,
            -.26190838401581408670e-4, .36899182659531622704e-5, };
    static final double HALF_LOG_2_PI = 0.5 * Math.log(2.0 * Math.PI);
    public static double lgamma(double x) {

        double ret;

        if (Double.isNaN(x)) {
            return x;
        }

        if (x >= 0 && x <= GAMMA_MINX) {
            x = GAMMA_MINX;
        }
        double g = 607.0 / 128.0;

        double sum = 0.0;
        for (int i = lanczos.length - 1; i > 0; --i) {
            sum = sum + (lanczos[i] / (x + i));
        }
        sum = sum + lanczos[0];

        double tmp = x + g + .5;
        ret = ((x + .5) * Math.log(tmp)) - tmp + HALF_LOG_2_PI
                + Math.log(sum / x);
        return ret;
    }
    public static double gamma(double x) {
        return Math.exp(lgamma(x));
    }
    public static double studentTDensity(double x, double mu, double sigma_sq, double nu){
//		 Double part1 = gamma((nu + 1) / 2) / gamma(nu / 2);
        Double part1 = Math.exp(lgamma((nu + 1) / 2) - lgamma(nu / 2));
        Double part2 = 1.0 / Math.sqrt(Math.PI * nu * sigma_sq);
        Double part3 = Math.pow((1 + (x - mu) * (x - mu ) / nu / sigma_sq), -(nu + 1) / 2);
        Double restult = part1 * part2 * part3;
        if(restult.isInfinite()){
            System.out.println(x+"\t"+mu+"\t"+sigma_sq+"\t"+nu);
            System.out.println(part1+"\t"+part2+"\t"+part3);
        }
        return part1 * part2 * part3;
    }
    public static int[][] matrixProduct(int[][] m1, int[][] m2){
        int[][] m = new int[m1.length][m2[0].length];
        for(int i = 0; i < m1.length; i++){
            for(int j = 0; j < m2[0].length; j++){
                for(int k = 0; k < m1[0].length; k++){
                    m[i][j] += m1[i][k] * m2[k][j];
                }
            }
        }
        return m;
    }
    public static int[][] matrixProductBinary(int[][] m1, int[][] m2){
        int[][] m = new int[m1.length][m2[0].length];
        for(int i = 0; i < m1.length; i++)
            for(int j = 0; j < m2[0].length; j++)
                for(int k = 0; k < m1[0].length; k++) {
                    m[i][j] += m1[i][k] * m2[k][j];
                    if(m[i][j] > 0)
                        m[i][j] = 1;
                }
        return m;
    }
    public static double entropy(Map<Integer, Integer> map){
        double[] prob = new double[map.size()];
        int idx = 0;
        for(Entry<Integer, Integer> entry : map.entrySet()){
            prob[idx] = entry.getValue();
            idx++;
        }
        Utility.normalizeL1(prob);
        double entropy = 0;
        for(idx = 0; idx < prob.length; idx++)
            entropy -= prob[idx] * Math.log(prob[idx]);
        return entropy;
    }
}
