package util;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by quanyuan on 9/25/16.
 */
public class Sent {
    public ArrayList<Integer> crfid_al, emid_al;
    public int size;
    public Sent(ArrayList<Integer> crfid_al, ArrayList<Integer> emid_al) {
        this.crfid_al = crfid_al;
        this.emid_al = emid_al;
        size = crfid_al.size();
    }
    public String toString(HashMap<Integer, String> crfid_crf, HashMap<Integer, String> emid_em){
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < size; i++){
            sb.append("<"+crfid_crf.get(crfid_al.get(i))+" -- "+emid_em.get(emid_al.get(i))+">");
            if(i != size - 1)
                sb.append(", ");
        }
        return sb.toString();
    }
}
