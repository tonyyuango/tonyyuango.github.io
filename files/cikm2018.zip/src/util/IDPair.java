package util;

import java.util.HashMap;

/**
 * Created by Quan Yuan on 9/20/2016.
 */
public class IDPair {
    public int id1, id2;

    public IDPair(int id1, int id2) {
        this.id1 = id1;
        this.id2 = id2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        IDPair idPair = (IDPair) o;

        if (id1 != idPair.id1) return false;
        return id2 == idPair.id2;

    }

    @Override
    public int hashCode() {
        int result = id1;
        result = 31 * result + id2;
        return result;
    }
    public String toString(HashMap<Integer, String> id_key){
        return id_key.get(id1)+"\t"+id_key.get(id2);
    }
}
