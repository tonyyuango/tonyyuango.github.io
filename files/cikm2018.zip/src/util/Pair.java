package util;

/**
 * Created by quanyuan on 9/21/16.
 */
public class Pair {
    public int id1, id2;
    public Pair(int id1, int id2){
        this.id1 = Utility.min(id1, id2);
        this.id2 = Utility.max(id1, id2);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Pair pair = (Pair) o;

        if (id1 != pair.id1) return false;
        return id2 == pair.id2;

    }

    @Override
    public int hashCode() {
        int result = id1;
        result = 31 * result + id2;
        return result;
    }

    @Override
    public String toString() {
        return "Pair{" +
                "id1=" + id1 +
                ", id2=" + id2 +
                '}';
    }
}
